<?php 

session_start();

	include("connection.php");
	include("functions.php");


	if($_SERVER['REQUEST_METHOD'] == "POST")
	{
		//something was posted
		$user_name = $_POST['user_name'];
		$password = $_POST['password'];

		if(!empty($user_name) && !empty($password) && !is_numeric($user_name))
		{

			//read from database
			$query = "select * from users where user_name = '$user_name' limit 1";
			$result = mysqli_query($con, $query);

			if($result)
			{
				if($result && mysqli_num_rows($result) > 0)
				{

					$user_data = mysqli_fetch_assoc($result);
					
					if($user_data['password'] === $password)
					{

						$_SESSION['user_id'] = $user_data['user_id'];
						header("Location: about.php");
						die;
					}
				}
			}
			
			echo "wrong username or password!";
		}else
		{
			echo "wrong username or password!";
		}
	}

?>



<!DOCTYPE html>
    
    <head>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia">
    <title>Login</title>
    </head>
   
<body>

<style type="text/css">

  
  body {
  background-image: url("background.png");
  font-family: "Sofia", sans-serif;
} 
	
	#text{

		height: 25px;
		border-radius: 5px;
		padding: 4px;
		border: solid thin #aaa;
		width: 100%;
	}

	#button{

		padding: 10px;
		width: 100px;
		color: white;
		background-color: lightblue;
		border: none;
	}

	#box{

		background-color:#454545;
		margin: auto;
		width: 300px;
		padding: 20px;
	}

  .wrapper span {
	position: fixed;
	bottom: -50px;
	height: 30px;
	width: 30px;
	border-radius: 50%;
    
	animation: animate 10s linear infinite;
    background-image: url("2000540.jpg")
}
.wrapper span:nth-child(1) {
	left: 0;
	animation-delay: .6s;
    
    background-color: rgba(81, 224, 15, 0.123);
}
.wrapper span:nth-child(2) {
	left: 10%;
	animation-delay: 3s;
	background-color: #fff;
}
.wrapper span:nth-child(3) {
	left: 20%;
	animation-delay: 2s;
	background-color: #fff;
}
.wrapper span:nth-child(4) {
	left: 30%;
	animation-delay: 5s;
	background-color: #fff;
}
.wrapper span:nth-child(5) {
	left: 40%;
	animation-delay: 1s;
	background-color: #fff;
}
.wrapper span:nth-child(6) {
	left: 50%;
	animation-delay: 7s;
	background-color: #000;
}
.wrapper span:nth-child(7) {
	left: 60%;
	animation-delay: 6s;
	background-color: #000;
}
.wrapper span:nth-child(8) {
	left: 70%;
	animation-delay: 8s;
	background-color: #000;
}
.wrapper span:nth-child(9) {
	left: 80%;
	animation-delay: 6s;
	background-color: #000;
}
.wrapper span:nth-child(10) {
	left: 90%;
	animation-delay: 4s;
	background-color: #000;
}
@keyframes animate {
	0% {
		bottom: 0%;
		margin-left: 90px;
		margin-right: 0px;
	}
	20% {
		bottom: 20%;
		margin-left: 0px;
		margin-right: 90px;
	}
	40% {
		bottom: 40%;
		margin-left: 90px;
		margin-right: 0px;
	}
	60% {
		bottom: 60%;
		margin-left: 0px;
		margin-right: 90px;
	}
	80% {
		bottom: 80%;
		margin-left: 90px;
		margin-right: 0px;
	}
	100% {
		bottom: 100%;
		margin-left: 0px;
		margin-right: 90px;
	}
}
 .back{
     margin-left: 10px;
 }

	</style>

<div class="wrapper">
    <span></span>
    <span></span>
    <span></span>
    <span></span>
    <span></span>
    <span></span>
    <span></span>
    <span></span>
    <span></span>
    <span></span>
</div>

<div id="box">
		
		<form method="post">
			<div style="font-size: 40px;margin: 10px;color: white;">Log in</div>
<P id=pu style="color:white">USER Name</P>
			<input id="text" type="text" name="user_name"><br><br>
      <P id=pu style="color:white">PassWord</P>
			<input id="text" type="password" name="password"><br><br>

			<input id="button" type="submit" value="Login"><br><br>

			<a href="First_page.php" style="color:white">Back</a><br><br>
		</form>
	</div>
</body>
</html>


  
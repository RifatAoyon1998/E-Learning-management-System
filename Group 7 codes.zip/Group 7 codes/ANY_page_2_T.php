<html>
    <head>
<style>
body {
  width: 100%;
  height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: #eb0c0c;
}

svg {
  width: 256px;
  height: 256px;
}

/* SMOKE */
#smoke-1 {
  stroke-dasharray: 0, 10;
  animation: smoke 6s ease infinite;
}

#smoke-2 {
  stroke-dasharray: 0, 10;
  animation: smoke 6s 0.5s ease infinite;
}

@keyframes smoke {
  0% { stroke-dasharray: 0, 10; }
  50% { stroke-dasharray: 10, 0; }
  100% { stroke-dasharray: 10, 0; opacity: 0; }
}

/* WRITING */
#line-1 {
  opacity: 0;
  animation: writing 0.5s linear forwards;
}

#line-2 {
  opacity: 0;
  animation: writing 0.5s 1s linear forwards;
}

#line-3 {
  opacity: 0;
  animation: writing 0.5s 1.5s linear forwards;
}

#line-4 {
  opacity: 0;
  animation: writing 0.5s 2s linear forwards;
}

@keyframes writing {
  0% { width: 0px; opacity: 1;}
  100% { width: 14px; opacity: 1;}
}





/*
=====
CORE STYLES
=====
*/

.mask{
  --uiMaskClipPath: var(--maskClipPath);

  box-sizing: var(--maskBoxSizing, border-box);
  display: var(--maskDisplay, inline-flex);
  padding: var(--maskStrokeThickness, 3px);
  clip-path: var(--uiMaskClipPath);
  background-color: var(--maskStrokeColor, currentColor);
}

.mask__img{
  max-width: 100%;
  display: block;
  clip-path: var(--uiMaskClipPath);
}

.mask, 
.mask__img{
  transition: clip-path var(--maskAnimationDuration, .2s) var(--maskAnimationTimingFunction, ease-out);
}

/* masks */

.mask_type1{
  --maskClipPath: polygon(0 10%, 10% 0, 90% 0, 100% 10%, 100% 90%, 90% 100%, 10% 100%, 0 90%);
}

.mask_type2{
  --maskClipPath: polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%);
}

.mask_type3{
  --maskClipPath: polygon(0 10%, 10% 10%, 10% 0, 90% 0, 90% 10%, 100% 10%, 100% 90%, 90% 90%, 90% 100%, 10% 100%, 10% 90%, 0 90%);
}

.mask_type4{
  --maskClipPath: polygon(0 50%, 50% 0, 100% 50%, 50% 100%);
}

/* effect 1*/

.mask_type1-a1{
  --maskAnimationDuration: .4s;
}

.mask_type1:hover, 
.mask_type1:focus{
  --maskClipPath: polygon(0 0, 100% 0, 100% 10%, 100% 100%, 90% 100%, 0% 100%, 0% 90%, 0% 10%);
}

/* effect 2*/

.mask_type2-a1{
  --maskAnimationDuration: .4s;
}

.mask_type2:hover, 
.mask_type2:focus{
  --maskClipPath: polygon(100% 0, 100% 50%, 100% 100%, 0 100%, 0% 50%, 0 0);
}

/* effect 3*/

.mask_type3-a1{
  --maskAnimationDuration: .5s
}

.mask_type3:hover, 
.mask_type3:focus{
  --maskClipPath: polygon(90% 0, 100% 0, 100% 10%, 100% 90%, 100% 100%, 90% 100%, 10% 100%, 0 100%, 0 90%, 0 10%, 0 0, 10% 0);
}

/* effect 4*/

.mask_type4:hover, 
.mask_type4:focus{
  --maskClipPath: polygon(0 0, 100% 0, 100% 100%, 0 100%);
}

/* effect 5*/

.mask_type1-a2{
  --maskAnimationDuration: .5s;
}

.mask_type1-a2:hover, 
.mask_type1-a2:focus{
  --maskClipPath: polygon(0 0, 90% 0, 100% 0, 100% 90%, 100% 100%, 10% 100%, 0 100%, 0 10%); 
}

/* effect 6*/

.mask_type2-a2{
  --maskAnimationDuration: .9s;
  --maskAnimationTimingFunction: cubic-bezier(1, 0.18, 0, 1.14);
}

/*
=====
SETTINGS
=====
*/

.mask{
  --maskStrokeColor: #ecebef;
  --maskStrokeThickness: 5px;
}

/*
=====
DEMO
=====
*/



.page{
  box-sizing: border-box;
  width: 100%;
  padding: 1.5rem;
  margin: auto;  
  text-align: center;

  display: grid; 
  grid-gap: 3rem; 
  grid-template-columns: repeat(auto-fit, 15rem);
  justify-content: center;
}

.page__caption{
  display: inline-block; 
  padding: .5rem 2rem;

  background-color: #ecebef;
  font-size: 1rem; 
  color: #211e25; 
  text-transform: uppercase;
}

.page__demo{ 
  margin-top: 1.5rem;  
}

.page__tile{ 
  width: 9rem; 
  height: 9rem; 
}











body {
  font-family: Alegreya Sans;
  background: rgba(0, 0, 0, 0.322);
}
.menu {
  position: relative;
  background: #cd3e3d;
  width: 3em;
  height: 3em;
  border-radius: 5em;
  margin: auto;
  margin-top: 5em;
  margin-bottom: 5em;
  cursor: pointer;
  border: 1em solid #fdaead;
}
.menu:after {
  content: "";
  position: absolute;
  top: 1em;
  left: 1em;
  width: 1em;
  height: 0.2em;
  border-top: 0.6em double #fff;
  border-bottom: 0.2em solid #fff;
}
.menu ul {
  list-style: none;
  padding: 0;
}
.menu li {
  width: 5em;
  height: 1.4em;
  padding: 0.2em;
  margin-top: 0.2em;
  text-align: center;
  border-top-right-radius: 0.5em;
  border-bottom-right-radius: 0.5em;
  transition: all 1s;
  background: #fdaead;
  opacity: 0;
  z-index: -1;
}
.menu:hover li {
  opacity: 1;
}
/**
 * Add a pseudo element to cover the space
 * between the links. This is so the menu
 * does not lose :hover focus and disappear
 */
.menu:hover ul::before {
  position: absolute;
  content: "";
  width: 0;
  height: 0;
  display: block;
  left: 50%;
  top: -5.0em;
  /**
   * The pseudo-element is a semi-circle
   * created with CSS. Top, bottom, and right
   * borders are 6.5em (left being 0), and then
   * a border-radius is added to the two corners
   * on the right.
   */
  border-width: 6.5em;
  border-radius: 0 7.5em 7.5em 0;
  border-left: 0;
  border-style: solid;
  /**
   * Have to have a border color for the border
   * to be hoverable. I'm using a very light one
   * so that it looks invisible.
   */
  border-color: rgba(0,0,0,0.01);
  /**
   * Put the psuedo-element behind the links
   * (So they can be clicked on)
   */
  z-index: -1;
  /**
   * Make the cursor default so it looks like
   * nothing is there
   */
  cursor: default;
}
.menu a {
  color: white;
  text-decoration: none;
  /**
   * This is to vertically center the text on the
   * little tab-like things that the text is on.
   */
  line-height: 1.5em;
}
.menu a {
  color: white;
  text-decoration: none;
}
.menu ul {
  transform: rotate(180deg) translateY(-2em);
  transition: 1s all;
}
.menu:hover ul {
  transform: rotate(0deg) translateY(-1em);
}
.menu li:hover {
  background: #cd3e3d;
  z-index: 10;
}

.menu li:nth-of-type(1) {
  transform: rotate(-90deg);
  position: absolute;
  left: -1.2em;
  top: -4.2em;
}
.menu li:nth-of-type(2) {
  transform: rotate(-45deg);
  position: absolute;
  left: 2em;
  top: -3em;
}
.menu li:nth-of-type(3) {
  position: absolute;
  left: 3.4em;
  top: 0.3em;
}
.menu li:nth-of-type(4) {
  transform: rotate(45deg);
  position: absolute;
  left: 2em;
  top: 3.7em;
}
.menu li:nth-of-type(5) {
  transform: rotate(90deg);
  position: absolute;
  left: -1.2em;
  top: 5em;
}
.hint {
  text-align: center;
}











</style>
    </head><body>
<!-- Designed with Figma -->




<svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
<g id="study">
<rect width="64" height="64"/>
<g id="smoke">
<path id="smoke-2" d="M9 21L9.55279 19.8944C9.83431 19.3314 9.83431 18.6686 9.55279 18.1056L9 17L8.44721 15.8944C8.16569 15.3314 8.16569 14.6686 8.44721 14.1056L9 13" stroke="#797270"/>
<path id="smoke-1" d="M6.5 22L7.05279 20.8944C7.33431 20.3314 7.33431 19.6686 7.05279 19.1056L6.5 18L5.94721 16.8944C5.66569 16.3314 5.66569 15.6686 5.94721 15.1056L6.5 14" stroke="#797270"/>
</g>
<g id="laptop">
<rect id="laptop-base" x="17" y="28" width="20" height="3" fill="#F3F3F3" stroke="#453F3C" stroke-width="2"/>
<rect id="laptop-screen" x="18" y="17" width="18" height="11" fill="#5A524E" stroke="#453F3C" stroke-width="2"/>
<rect id="line-1" x="20" y="19" width="14" height="1" fill="#F78764"/>
<rect id="line-2" x="20" y="21" width="14" height="1" fill="#F9AB82"/>
<rect id="line-3" x="20" y="23" width="14" height="1" fill="#F78764"/>
<rect id="line-4" x="20" y="25" width="14" height="1" fill="#F9AB82"/>
</g>
<g id="cup">
<rect id="Rectangle 978" x="5" y="24" width="5" height="7" fill="#CCC4C4" stroke="#453F3C" stroke-width="2"/>
<path id="Ellipse 416" d="M11 28C12.1046 28 13 27.1046 13 26C13 24.8954 12.1046 24 11 24" stroke="#453F3C" stroke-width="2"/>
<rect id="Rectangle 996" x="6" y="25" width="3" height="1" fill="#D6D2D1"/>
</g>
<g id="books">
<rect id="Rectangle 984" x="58" y="27" width="4" height="14" transform="rotate(90 58 27)" fill="#B16B4F" stroke="#453F3C" stroke-width="2"/>
<rect id="Rectangle 985" x="56" y="23" width="4" height="14" transform="rotate(90 56 23)" fill="#797270" stroke="#453F3C" stroke-width="2"/>
<rect id="Rectangle 986" x="60" y="19" width="4" height="14" transform="rotate(90 60 19)" fill="#F78764" stroke="#453F3C" stroke-width="2"/>
<rect id="Rectangle 993" x="47" y="20" width="12" height="1" fill="#F9AB82"/>
<rect id="Rectangle 994" x="43" y="24" width="12" height="1" fill="#54504E"/>
<rect id="Rectangle 995" x="45" y="28" width="12" height="1" fill="#804D39"/>
</g>
<g id="desk">
<rect id="Rectangle 973" x="4" y="31" width="56" height="5" fill="#797270" stroke="#453F3C" stroke-width="2"/>
<rect id="Rectangle 987" x="10" y="36" width="30" height="6" fill="#797270" stroke="#453F3C" stroke-width="2"/>
<rect id="Rectangle 975" x="6" y="36" width="4" height="24" fill="#797270" stroke="#453F3C" stroke-width="2"/>
<rect id="Rectangle 974" x="40" y="36" width="18" height="24" fill="#797270" stroke="#453F3C" stroke-width="2"/>
<line id="Line 129" x1="40" y1="48" x2="58" y2="48" stroke="#453F3C" stroke-width="2"/>
<line id="Line 130" x1="22" y1="39" x2="28" y2="39" stroke="#453F3C" stroke-width="2"/>
<line id="Line 142" x1="46" y1="42" x2="52" y2="42" stroke="#453F3C" stroke-width="2"/>
<line id="Line 131" x1="46" y1="54" x2="52" y2="54" stroke="#453F3C" stroke-width="2"/>
<rect id="Rectangle 988" x="11" y="37" width="28" height="1" fill="#54504E"/>
<rect id="Rectangle 992" x="5" y="32" width="54" height="1" fill="#9E9492"/>
<rect id="Rectangle 989" x="7" y="37" width="2" height="1" fill="#54504E"/>
<rect id="Rectangle 990" x="41" y="37" width="16" height="1" fill="#54504E"/>
<rect id="Rectangle 991" x="41" y="49" width="16" height="1" fill="#54504E"/>
<line id="Line 143" y1="60" x2="64" y2="60" stroke="#453F3C" stroke-width="2"/>
</g>
</g>
</svg>




<link href='https://fonts.googleapis.com/css?family=Alegreya+Sans:400,800' rel='stylesheet' type='text/css'>
<nav class="menu">
  <ul>
    <li><a href="about_t.php">About</a></li>
    <li><a href="noneed.php">Contact</a></li>
    <li><a href="fun_T.php">Remove Materials</a></li>
    <li><a href="welcome.php">Main Menu</a></li>
    <li><a href="logout_2.php">Log out</a></li>
  </ul>
</nav>
<B> Menu</B>













<div class="page">
    <div class="page__container">
      <span class="page__caption">CSE 110</span>
      <div class="page__demo">
        <a href="inside_course_T.php" class="mask mask_type1 mask_type1-a1 page__tile">
          <img src="https://content.techgig.com/thumb/msid-75405391,width-860,resizemode-4/Top-universities-offering-free-online-courses-for-programmers.jpg?125255" class="mask__img" alt="The avatar of Stas Melnikov">
        </a>
      </div>
    </div>
    <div class="page__container">
      <span class="page__caption">CSE 111</span>
      <div class="page__demo">
        <a href="inside_course_T_111.php" class="mask mask_type2 mask_type2-a1 page__tile">
          <img src="https://www.roberthalf.com/sites/default/files/2018-03/Object%20oriented%20programming.jpg" class="mask__img" alt="The avatar of Stas Melnikov">
        </a>
      </div>
    </div>
    <div class="page__container">
      <span class="page__caption">CSE 220</span>
      <div class="page__demo">
        <a href="inside_course_T_220.php" class="mask mask_type3 mask_type3-a1 page__tile">
          <img src="https://www.skillrary.com/uploads/updatedimages/883_medium.png" class="mask__img" alt="The avatar of Stas Melnikov">
        </a>
      </div>
    </div>      
    <div class="page__container">
      <span class="page__caption">CSE 221</span>
      <div class="page__demo">
        <a href="inside_course_T_221.php" class="mask mask_type4 mask_type4-a1 page__tile">
          <img src="https://bsmedia.business-standard.com/media-handler.php?mediaPath=https://bsmedia.business-standard.com/_media/bs/img/article/2016-11/29/full/1480399656-597.jpg&width=1200" class="mask__img" alt="The avatar of Stas Melnikov">
        </a>
      </div>
    </div>
    <div class="page__container">
      <span class="page__caption">CSE 321</span>
      <div class="page__demo">
        <a href="inside_course_T_321.php" class="mask mask_type1 mask_type1-a2 page__tile">
          <img src="https://www.deskdecode.com/wp-content/uploads/2017/04/operating-system-icon-5746821.jpg" class="mask__img" alt="The avatar of Stas Melnikov">
        </a>
      </div>
    </div>  
    <div class="page__container">
      <span class="page__caption">CSE 330</span>
      <div class="page__demo">
        <a href="inside_course_T_330.php" class="mask mask_type2 mask_type2-a2 page__tile">
          <img src="https://i.ytimg.com/vi/_6gadj9-FFs/maxresdefault.jpg" class="mask__img" alt="The avatar of Stas Melnikov">
        </a>
      </div>      
    </div>
  </div>
  
  

    </body>
</html>
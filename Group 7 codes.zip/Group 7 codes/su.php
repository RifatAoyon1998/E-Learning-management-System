<?php 
session_start();

	include("connection.php");
	include("functions.php");


	if($_SERVER['REQUEST_METHOD'] == "POST")
	{
		//something was posted
		$user_name = $_POST['user_name'];
		$password = $_POST['password'];

		if(!empty($user_name) && !empty($password) && !is_numeric($user_name))
		{

			//save to database
			$user_id = random_num(20);
			$query = "insert into users (user_id,user_name,password) values ('$user_id','$user_name','$password')";

			mysqli_query($con, $query);

			header("Location: Sign_In.php");
			die;
		}else
		{
			echo "Please enter some valid information!";
		}
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Signup</title>
</head>
<body>

	<style type="text/css">
		body {
  background-image: url("background.png");
  font-family: "Sofia", sans-serif;
} 
	
	#text{

		height: 25px;
		border-radius: 5px;
		padding: 4px;
		border: solid thin #aaa;
		width: 100%;
	}

	#button{

		padding: 10px;
		width: 100px;
		color: white;
		background-color: lightblue;
		border: none;
	}

	#box{

		background-color: grey;
		margin: auto;
		width: 300px;
		padding: 20px;
	}
	.wrapper span {
	position: fixed;
	bottom: -50px;
	height: 30px;
	width: 30px;
	border-radius: 50%;
    
	animation: animate 10s linear infinite;
    background-image: url("2000540.jpg")
}
.wrapper span:nth-child(1) {
	left: 0;
	animation-delay: .6s;
    
    background-color: rgba(81, 224, 15, 0.123);
}
.wrapper span:nth-child(2) {
	left: 10%;
	animation-delay: 3s;
	background-color: #fff;
}
.wrapper span:nth-child(3) {
	left: 20%;
	animation-delay: 2s;
	background-color: #fff;
}
.wrapper span:nth-child(4) {
	left: 30%;
	animation-delay: 5s;
	background-color: #fff;
}
.wrapper span:nth-child(5) {
	left: 40%;
	animation-delay: 1s;
	background-color: #fff;
}
.wrapper span:nth-child(6) {
	left: 50%;
	animation-delay: 7s;
	background-color: #000;
}
.wrapper span:nth-child(7) {
	left: 60%;
	animation-delay: 6s;
	background-color: #000;
}
.wrapper span:nth-child(8) {
	left: 70%;
	animation-delay: 8s;
	background-color: #000;
}
.wrapper span:nth-child(9) {
	left: 80%;
	animation-delay: 6s;
	background-color: #000;
}
.wrapper span:nth-child(10) {
	left: 90%;
	animation-delay: 4s;
	background-color: #000;
}
@keyframes animate {
	0% {
		bottom: 0%;
		margin-left: 90px;
		margin-right: 0px;
	}
	20% {
		bottom: 20%;
		margin-left: 0px;
		margin-right: 90px;
	}
	40% {
		bottom: 40%;
		margin-left: 90px;
		margin-right: 0px;
	}
	60% {
		bottom: 60%;
		margin-left: 0px;
		margin-right: 90px;
	}
	80% {
		bottom: 80%;
		margin-left: 90px;
		margin-right: 0px;
	}
	100% {
		bottom: 100%;
		margin-left: 0px;
		margin-right: 90px;
	}
}
 .back{
     margin-left: 10px;
 }

	</style>
<div class="wrapper">
    <span></span>
    <span></span>
    <span></span>
    <span></span>
    <span></span>
    <span></span>
    <span></span>
    <span></span>
    <span></span>
    <span></span>
</div>
	<div id="box">
		
		<form method="post">
			<div style="font-size: 20px;margin: 10px;color: white;">Signup</div>
			<P id=pu style="color:white"> <br>USER Name</P>
			<input id="text" type="text" name="user_name"><br><br>
			<P id=pu style="color:white">Password</P>
			<input id="text" type="password" name="password"><br><br>
			<a href="file:///Users/macbook/Desktop/370_project/First_page.html">
			<input id="button" type="submit" value="Signup"><br><br>
</a>
			<a href="Sign_In.php">Click to Login</a><br><br>
		</form>
	</div>
</body>
</h>
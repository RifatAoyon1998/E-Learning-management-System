<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia">
	<title>Submit Marks</title>
	<style>
		 body{ 
			font-family: "Sofia", sans-serif;
            background-image: url("2000540.jpg");
            background-size: 100%;
             }
		input, textarea {
			display: block;
			width: 300px;
			font-size: 18px;
			margin: 7px 0px;
		}
		label {
			display: block;
			padding: 2px 0px;
		}
	</style>
</head>
<body>
	<h1> Submit Marks 111 </h1>
	
    <form method="post" action="send_111.php">
    	<label>Marks:</label>
    	<input type="text" 
    	       name="mark">
    
    	<label>ID:</label>
    	<textarea name="id"></textarea>

    	<input type="submit" 
    	       name="btn">
    </form>
	<p><a href="any_page_2_C.php">Click to Back</a></p>
	<p><a href="Mark_list_111.php">CSE 111 Students Marks List</a></p>
</body>
</html>
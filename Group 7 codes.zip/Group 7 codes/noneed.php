<html>
    <head>
        <script src="myScript.js"></script>
<style>
 
 @import url(https://fonts.googleapis.com/css?family=Montserrat);

html, body{
  height: 100%;
  font-weight: 800;
}

body{
    background: #03032148;

}

svg {
    display: block;
    font: 10.5em 'Montserrat';
    width: 560px;
    height: 300px;
    margin: 0 auto;
}

.text-copy {
    fill: none;
    stroke: white;
    stroke-dasharray: 6% 29%;
    stroke-width: 5px;
    stroke-dashoffset: 0%;
    animation: stroke-offset 5.5s infinite linear;
}

.text-copy:nth-child(1){
	stroke: #4D163D;
	animation-delay: -1;
}

.text-copy:nth-child(2){
	stroke: #840037;
	animation-delay: -2s;
}

.text-copy:nth-child(3){
	stroke: #BD0034;
	animation-delay: -3s;
}

.text-copy:nth-child(4){
	stroke: #BD0034;
	animation-delay: -4s;
}

.text-copy:nth-child(5){
	stroke: #FDB731;
	animation-delay: -5s;
}

@keyframes stroke-offset{
	100% {stroke-dashoffset: -35%;}
}



*{
  margin: 0;
  padding: 0;
  -webkit-box-sizing: border-box;
          box-sizing: border-box;
}

h1{
  font-size: 2.5rem;
  font-family: 'Montserrat';
  font-weight: normal;
  color: #444;
  text-align: center;
  margin: 2rem 0;
}

.wrapper{
  width: 90%;
  margin: 0 auto;
  max-width: 80rem;
}

.cols{
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -ms-flex-wrap: wrap;
      flex-wrap: wrap;
  -webkit-box-pack: center;
      -ms-flex-pack: center;
          justify-content: center;
}

.col{
  width: calc(25% - 2rem);
  margin: 1rem;
  cursor: pointer;
}

.container{
  -webkit-transform-style: preserve-3d;
          transform-style: preserve-3d;
	-webkit-perspective: 1000px;
	        perspective: 1000px;
}

.front,
.back{
  background-size: cover;
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.25);
  border-radius: 10px;
	background-position: center;
	-webkit-transition: -webkit-transform .7s cubic-bezier(0.4, 0.2, 0.2, 1);
	transition: -webkit-transform .7s cubic-bezier(0.4, 0.2, 0.2, 1);
	-o-transition: transform .7s cubic-bezier(0.4, 0.2, 0.2, 1);
	transition: transform .7s cubic-bezier(0.4, 0.2, 0.2, 1);
	transition: transform .7s cubic-bezier(0.4, 0.2, 0.2, 1), -webkit-transform .7s cubic-bezier(0.4, 0.2, 0.2, 1);
	-webkit-backface-visibility: hidden;
	        backface-visibility: hidden;
	text-align: center;
	min-height: 280px;
	height: auto;
	border-radius: 10px;
	color: #fff;
	font-size: 1.5rem;
}

.back{
  background: #cedce7;
  background: -webkit-linear-gradient(45deg,  #cedce7 0%,#596a72 100%);
  background: -o-linear-gradient(45deg,  #cedce7 0%,#596a72 100%);
  background: linear-gradient(45deg,  #cedce7 0%,#596a72 100%);
}

.front:after{
	position: absolute;
    top: 0;
    left: 0;
    z-index: 1;
    width: 100%;
    height: 100%;
    content: '';
    display: block;
    opacity: .6;
    background-color: #000;
    -webkit-backface-visibility: hidden;
            backface-visibility: hidden;
    border-radius: 10px;
}
.container:hover .front,
.container:hover .back{
    -webkit-transition: -webkit-transform .7s cubic-bezier(0.4, 0.2, 0.2, 1);
    transition: -webkit-transform .7s cubic-bezier(0.4, 0.2, 0.2, 1);
    -o-transition: transform .7s cubic-bezier(0.4, 0.2, 0.2, 1);
    transition: transform .7s cubic-bezier(0.4, 0.2, 0.2, 1);
    transition: transform .7s cubic-bezier(0.4, 0.2, 0.2, 1), -webkit-transform .7s cubic-bezier(0.4, 0.2, 0.2, 1);
}

.back{
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
}

.inner{
    -webkit-transform: translateY(-50%) translateZ(60px) scale(0.94);
            transform: translateY(-50%) translateZ(60px) scale(0.94);
    top: 50%;
    position: absolute;
    left: 0;
    width: 100%;
    padding: 2rem;
    -webkit-box-sizing: border-box;
            box-sizing: border-box;
    outline: 1px solid transparent;
    -webkit-perspective: inherit;
            perspective: inherit;
    z-index: 2;
}

.container .back{
    -webkit-transform: rotateY(180deg);
            transform: rotateY(180deg);
    -webkit-transform-style: preserve-3d;
            transform-style: preserve-3d;
}

.container .front{
    -webkit-transform: rotateY(0deg);
            transform: rotateY(0deg);
    -webkit-transform-style: preserve-3d;
            transform-style: preserve-3d;
}

.container:hover .back{
  -webkit-transform: rotateY(0deg);
          transform: rotateY(0deg);
  -webkit-transform-style: preserve-3d;
          transform-style: preserve-3d;
}

.container:hover .front{
  -webkit-transform: rotateY(-180deg);
          transform: rotateY(-180deg);
  -webkit-transform-style: preserve-3d;
          transform-style: preserve-3d;
}

.front .inner p{
  font-size: 2rem;
  margin-bottom: 2rem;
  position: relative;
}

.front .inner p:after{
  content: '';
  width: 4rem;
  height: 2px;
  position: absolute;
  background: #C6D4DF;
  display: block;
  left: 0;
  right: 0;
  margin: 0 auto;
  bottom: -.75rem;
}

.front .inner span{
  color: rgba(255,255,255,0.7);
  font-family: 'Montserrat';
  font-weight: 300;
}

@media screen and (max-width: 64rem){
  .col{
    width: calc(33.333333% - 2rem);
  }
}

@media screen and (max-width: 48rem){
  .col{
    width: calc(50% - 2rem);
  }
}

@media screen and (max-width: 32rem){
  .col{
    width: 100%;
    margin: 0 0 2rem 0;
  }
}




</style>
    </head>
    <body>

        <svg viewBox="0 0 960 300">
            <symbol id="s-text">
                <text text-anchor="middle" x="50%" y="80%">Contact</text>
            </symbol>
        
            <g class = "g-ants">
                <use xlink:href="#s-text" class="text-copy"></use>
                <use xlink:href="#s-text" class="text-copy"></use>
                <use xlink:href="#s-text" class="text-copy"></use>
                <use xlink:href="#s-text" class="text-copy"></use>
                <use xlink:href="#s-text" class="text-copy"></use>
            </g>
        </svg>

<div class="wrapper">
            
            <div class="cols">
                      <div class="col" ontouchstart="this.classList.toggle('hover');">
                          <div class="container">
                              <div class="front" style="background-image: url(https://www.koimoi.com/wp-content/new-galleries/2020/04/money-heist-alvaro-morte-had-to-audition-these-many-times-to-bag-the-role-of-professor-in-la-casa-de-papel-001.jpg)">
                                  <div class="inner">
                                      <p>Mr. XYZ</p>
                        <span>Professor</span>
                                  </div>
                              </div>
                              <div class="back">
                                  <div class="inner">
                                    <p>Mobile: 01313123<br><u><b>Email:</b></u><br>xyz@gmail.com</p>
                                  </div>
                              </div>
                          </div>
                      </div>
                      <div class="col" ontouchstart="this.classList.toggle('hover');">
                          <div class="container">
                              <div class="front" style="background-image: url(https://www.euractiv.com/wp-content/uploads/sites/2/2019/05/Alemanno-800x450.jpg)">
                                  <div class="inner">
                                      <p>Mr. ABC</p>
                        <span>Professor</span>
                                  </div>
                              </div>
                              <div class="back">
                                  <div class="inner">
                                    <p>Mobile: 01313123<br><u><b>Email:</b></u><br>xyz@gmail.com</p>
                                  </div>
                              </div>
                          </div>
                      </div>
                      <div class="col" ontouchstart="this.classList.toggle('hover');">
                          <div class="container">
                              <div class="front" style="background-image: url(https://www.escp.eu/sites/default/files/styles/large/public/import_academ/394751.jpg?itok=hQI4L4iD)">
                                  <div class="inner">
                                      <p>Mr ACB</p>
                        <span>Professor</span>
                                  </div>
                              </div>
                              <div class="back">
                                  <div class="inner">
                                    <p>Mobile: 01313123<br><u><b>Email:</b></u><br>xyz@gmail.com</p>
                                  </div>
                              </div>
                          </div>
                      </div>
                      <div class="col" ontouchstart="this.classList.toggle('hover');">
                          <div class="container">
                              <div class="front" style="background-image: url(https://www.conncoll.edu/media/Levi,-Jacob---image-400x400.jpeg)">
                                  <div class="inner">
                                      <p>Mr MNZ</p>
                        <span>Professor</span>
                                  </div>
                              </div>
                              <div class="back">
                                  <div class="inner">
                                    <p>Mobile: 01313123<br><u><b>Email:</b></u><br>xyz@gmail.com</p>
                                  </div>
                              </div>
                          </div>
                      </div>
                      <div class="col" ontouchstart="this.classList.toggle('hover');">
                          <div class="container">
                              <div class="front" style="background-image: url(https://www.depts.ttu.edu/classic_modern/french/images/Penteado.jpg">
                                  <div class="inner">
                                      <p>Mr RSA</p>
                        <span>Professor</span>
                                  </div>
                              </div>
                              <div class="back">
                                  <div class="inner">
                                    <p>Mobile: 01313123<br><u><b>Email:</b></u><br>xyz@gmail.com</p>
                                  </div>
                              </div>
                          </div>
                      </div>
                      <div class="col" ontouchstart="this.classList.toggle('hover');">
                          <div class="container">
                              <div class="front" style ="background-image: url(https://rightfromthestartmatters.com/wp-content/uploads/2016/04/Staff-Page-Professor-Paul-French.png)">
                                  <div class="inner">
                                      <p>Mr MAM</p>
                        <span>Professor</span>
                                  </div>
                              </div>
                              <div class="back">
                                  <div class="inner">
                                    <p>Mobile: 01313123<br><u><b>Email:</b></u><br>xyz@gmail.com</p>
                                  </div>
                              </div>
                          </div>
                      </div>
                      <div class="col" ontouchstart="this.classList.toggle('hover');">
                          <div class="container">
                              <div class="front" style="background-image: url(https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQsIaa4xDU-hC1m4LA1V4NL0Q-RHrPwIDXtoUZk6KBDDyLfRPwt9210CGmSk6Qz5PMMDeA&usqp=CAU)">
                                  <div class="inner">
                                      <p>Mr ABZ</p>
                        <span>Professor</span>
                                  </div>
                              </div>
                              <div class="back">
                                  <div class="inner">
                                    <p>Mobile: 01313123<br><u><b>Email:</b></u><br>xyz@gmail.com</p>
                                  </div>
                              </div>
                          </div>
                      </div>
                      <div class="col" ontouchstart="this.classList.toggle('hover');">
                          <div class="container">
                              <div class="front" style="background-image: url(https://chemistry.sciences.ncsu.edu/wp-content/uploads/sites/31/2020/09/Vincent-Gandon-500x500-1-300x300.jpg)">
                                  <div class="inner">
                                      <p>Mr YXZ</p>
                        <span>Professor</span>
                                  </div>
                              </div>
                              <div class="back">
                                  <div class="inner">
                                    <p>Mobile: 01313123<br><u><b>Email:</b></u><br>xyz@gmail.com</p>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
           </div>




    </body>
</html>
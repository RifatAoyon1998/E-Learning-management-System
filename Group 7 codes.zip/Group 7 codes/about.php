<?php 
session_start();

	include("connection.php");
	include("functions.php");

	$user_data = check_login($con);

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Glassmorphism Profile Card HTML CSS</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;600&display=swap" rel="stylesheet">
    <style>
        *{
	padding: 0;
	margin: 0;
	box-sizing: border-box;
}
.area{
	background-color: #4158D0;
	background-image: linear-gradient(45deg, #4158D0 0%, #C850C0 46%, #FFCC70 100%);
	width: 100%;
	height: 100vh;
}
.circles{
	position: absolute;
	top: 0;
	left: 0;
	width: 100%;
	height: 100%;
	overflow: hidden;
}
.circles li{
	position: absolute;
	display: block;
	list-style: none;
	width: 20px;
	height: 20px;
	background: rgba(255, 255, 255, 0.1);
	box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.2);
	backdrop-filter: blur(10px);
	-webkit-backdrop-filter: blur(10px);
	border-radius: 80px;
	border:1px solid rgba(255, 255, 255, 0.18);
	animation: animate 25s linear infinite;
	bottom: -150px;
}
@keyframes animate{
	0%{
		transform: translateY(0) rotate(0deg);
		opacity: 1;
		border-radius: 0;
	}
	100%{
		transform: translateY(-1000px) rotate(720deg);
		opacity: 0;
		border-radius: 50%;
	}
}

.circles li:nth-child(1){
	left:25%;
	width: 80px;
	height: 80px;
	animation-delay: 0s;
}
.circles li:nth-child(2){
	left:10%;
	width: 20px;
	height: 20px;
	animation-delay: 2s;
	animation-duration: 12s;
}
.circles li:nth-child(3){
	left:70%;
	width: 20px;
	height: 20px;
	animation-delay: 4s;
}
.circles li:nth-child(4){
	left:40%;
	width: 60px;
	height:60px;
	animation-delay: 0s;
	animation-duration:18s;
}
.circles li:nth-child(5){
	left:65%;
	width: 20px;
	height:20px;
	animation-delay: 0s;
}
.circles li:nth-child(6){
	left:75%;
	width: 110px;
	height:110px;
	animation-delay: 3s;
}
.circles li:nth-child(7){
	left:35%;
	width: 25px;
	height:25px;
	animation-delay: 7s;
}
.circles li:nth-child(8){
	left:50%;
	width: 25px;
	height:25px;
	animation-delay: 15s;
	animation-duration: 45s;
}
.circles li:nth-child(9){
	left:20%;
	width: 15px;
	height:15px;
	animation-delay: 2s;
	animation-duration: 35s;
}
.circles li:nth-child(10){
	left:85%;
	width: 150px;
	height:150px;
	animation-delay: 0s;
	animation-duration: 11s;
}

.card{
	width: 320px;
	height: 400px;
	background-color: rgba(255, 255, 255, 0.06);
	backdrop-filter: blur(20px);
	position: absolute;
	margin: auto;
	left: 0;
	right:0;
	top:0;
	bottom: 0;
	border-radius: 8px;
	box-shadow: 0px 0px 5px rgba(0,0,0, 0.2);
	font-family: "poppins", sans-serif;
	z-index: 100;
}
.card-img{
	width: 120px;
	height: 120px;
	background-color: rgba(255, 255, 255, 0.06);
	backdrop-filter: blur(20px);
	position: absolute;
	margin: 30px auto 20px auto;
	left:0;
	right: 0;
	border-radius: 50%;
}
.card-img img{
	border-radius: 50%;
	height: 86%;
	margin-left: 7%;
	margin-top: 7%;
}
.desc{
	width: 100%;
	text-align: center;
	position: absolute;
	top:160px;
}
.primary-text{
	font-size: 14px;
	color: #d5d5d5;
	font-weight: 600;
	letter-spacing: 0.7px;
	margin: 5px 0;
}
.secondary-text{
	font-size: 12px;
	color: #c0c0c0;
	font-weight: 500;
	letter-spacing:1px;
	margin: 5px 0;
	text-transform: uppercase;
}
.details{
	display: grid;
	width: 100%;
	height: 75px;
	grid-template-columns: auto auto;
	position: absolute;
	bottom: 0;
	background-color: rgba(255, 255, 255, 0.06);
	backdrop-filter: blur(20px);
	border-radius: 0 0 8px 8px;
	padding: 5px 0;
}
.details > div{
	text-align: center;
}
.details > div:first-child{
	border-right: 2px solid rgba(255, 255, 255, 0.08);
}
button{
	background-color: rgba(255, 255, 255, 0.06);
	backdrop-filter: blur(20px);
	position: absolute;
	width: 80%;
	left:10%;
	top: 240px;
	border:none;
	border-radius: 5px;
	padding: 15px 0px;
	text-transform: uppercase;
	font-size: 14px;
}
    </style>
</head>
<body>
    <div class="area">
      <ul class="circles">
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
      </ul>
    </div>

    <div class="card">
      <div class="card-img">
        <img src="https://www.licany.org/wp-content/uploads/2018/10/male.jpg" alt="Profile">
      </div>
      <div class="desc">
        <h6 class="primary-text"><?php echo $user_data['user_name']; ?></h6>
        <h6 class="secondary-text">Email: <?php echo $user_data['user_name']; ?>@aprendre.fr</h6>

        <h6 class="secondary-text">ID :<?php echo $user_data['id']; ?></h6>
      </div>
      <a href="main_menu.php"><button class="primary-text">Main Menu</button></a>
      <div class="details">
        <div class="rating">
        <a href="chat_list.php"> <h6 class="primary-text">Chat</h6></a>
        
        </div>
        <div class="activity">
         <a href="complain_list.php"> <h6 class="primary-text">Complain</h6></a>
        
        </div>
      </div>
    </div>
 
</body>
</html>
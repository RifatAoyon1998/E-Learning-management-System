<html>
    <head>
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia">
      
<style>

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: "Sofia", sans-serif;
}
body {
  background-image: url("https://lighthouse-tc.com/wp-content/uploads/2020/08/e-learning-header-bg.jpg");
  background-position: center;
  background-size: cover;
  height: 100vh;
  display: grid;
  
  place-items: Center;
  color: #fff;
}
.container {
  background-color: rgba(0, 0, 0, 0.5);
  max-width: 600px;
  width: 100%;
  padding: 2em 0px;
  backdrop-filter: blur(10px);
  border-radius: 10px;
}
.container h1 {
  text-align: center;
  padding: 10px;
  letter-spacing: 2px;
  font-size: 2em;
}
.container .list {
  position: relative;
  background: rgba(0, 0, 0, 0.2);
  width: 80%;
  margin: 20px auto;
  display: flex;
  align-items: center;
  backdrop-filter: blur(10px);
  border-radius: 10px;
  overflow: hidden;
}
.container .list img {
  height: 100px;
  width: 100px;
  object-fit: cover;
}

.container .list i {
  position: absolute;
  right: 0;
  padding: 0 5rem;
  height: 100%;
  display: grid;
  align-items: center;
  padding: 0px 20px;
  background: #f90c;
  background-size: 100px 100px;
  font-size: 1.3em;
  opacity: 0.5;
  transition: 0.2s;
  overflow: hidden;
}
.container .list:hover > i {
  opacity: 1;
}
.container .list .wrapper {
  padding-left: 10px;
}
.container .list .wrapper h3 {
  text-align: center;
  padding: 10px;
  letter-spacing: 2px;
  font-family: "Sofia", sans-serif;
  font-size: 1.2em;
}
.container .list .wrapper p {
  padding: 5px;
  margin-left: 9px;
  letter-spacing: 2px;
  font-family: "Sofia", sans-serif;
  font-size: 0.7em;
  color: #c6c6c6;
}


nav {
  margin: -2px;
  
  margin-top: 4px;
  position: relative;
  width: 200px;
  min-width: 320px;
  height: 200px;
}

nav h2 {
  border-radius: 2px;
  position: relative;
  background: #18222d;
  height: 40px;
  text-transform: uppercase;
  color: ivory;
  font-weight: 200;
  display: flex;
  flex: 1;
  justify-content: center;
  align-items: center;
  box-shadow: 4px 4px 20px -2px rgba(0,0,0,.35);
  transition: all .4s;
}

nav:hover h2{
  transform: translateY(-2px);
  box-shadow: 2px 2px 5px -1px rgba(0,0,0,.35);
 }
nav:hover:active h2{
  transform: translateY(10px);
  box-shadow: 0px -1px 2px 0px rgba(0,0,0,.35);
 }

input {
  position: absolute;
  left: 0;
  top: 0;
  width: 100%;
  z-index: 1;
  opacity: 0;
  cursor: pointer;
  height: 40px;
}

#toggle:checked ~ul {
  height: 0%;
}

nav ul {
  padding-left: 0;
  padding-top: 0;
  margin-top: 0;
  list-style: none;
  overflow: hidden;
  text-align: right;
  margin-bottom: 22px;
  text-align: center;
  transition: all .4s ease-out;
  height: 100%;
  
}
nav ul li {
  border-radius: 200px;
  position: relative;
  display: inline-block;
  margin-left: 35px;
  line-height: 1.5;
  width: 100%;
  margin: 0;
  margin-bottom: 5px;
  background: tomato;
  transition: background 3s;
  box-shadow: 2px 2px 10px -2px rgba(0,0,0,.35);
}

nav ul li:hover {
  background: mediumorchid;
  transition: background .45s;
}

nav ul a {
  display: block;
  color: ivory;
  text-transform: lowercase;
  font-size: 18px;
  font-weight: 200;
  text-decoration: none;
  transition: color .3s;
}

</style>
    </head>
   
    <body>
      
        <nav>
            <h2>Back To   ></h2>
             <input id="toggle" type="checkbox" checked>
          <ul>
            <ul>
            <li><a href="about.php">About</a></li>
    <li><a href="Any_page_2.php">Courses</a></li>
    <li><a href="fun.php">Library</a></li>
    <li><a href="main_menu.php">Main Menu</a></li>
    <li><a href="First_page.php">Log out</a></li>
              </ul>
          </ul>
       </nav>
        <div class="container">
            <h1>CSE 321</h1>
            <div class="list">
              <img src="https://around.uoregon.edu/sites/around2.uoregon.edu/files/styles/landscape/public/field/image/lecture_hall-shutterstock.jpg?itok=rFJ0bRnE" alt="">
              <div class="wrapper">
               <a href="LEC_321_list.php"> <h3>Lectures </h3></a>
                
              </div>
              <i class="fa fa-shopping-cart"></i>
            </div>
            <div class="list">
              <img src="https://www.residencestyle.com/wp-content/uploads/2021/02/Assignment-3.jpg" alt="">
              <div class="wrapper">
              <a href="ASN_321_list.php">  <h3>Assignment</h3></a>
               
              </div>
              <i class="fa fa-shopping-cart"></i>
            </div>
            <div class="list">
              <img src="https://cache.careers360.mobi/media/presets/900X600/article_images/2021/2/19/shutterstock_1664708983.jpg" alt="">
              <div class="wrapper">
              <a href="QUIZ_321_list.php">   <h3>Exam</h3></a>
                
                
              </div>
              <i class="fa fa-shopping-cart"></i>
            </div>
          

          



          </div> 
      
    </body>
</html>
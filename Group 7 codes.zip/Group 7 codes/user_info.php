
<!DOCTYPE html> 
<html> 
	<head> 
		<title> Fetch Data From Database </title> 
	</head> 
	<body> 
	<table> 
	<tr> 
		<th colspan="4"><h2>Student Record</h2></th> 
		</tr> 
			  <th> ID </th> 
			  <th> Name </th> 
			  <th> Password </th> 
			  
			  
		</tr> 
		
		<?php
        $con=mysqli_connect("localhost","root","","login_sample_db");
        if($con->connect_error){
            die("Failed".$con->connect_error);
        }
        $sql="select id,user_name,password from users";

       $result = $con->query($sql);
       if($result-> num_rows>0){
           while($row = $result-> fetch_assoc()){
               echo "<tr><td>".$row["id"]."</td><td>".$row["user_name"]."</td><td>".$row["password"]."</td><tr>";
           }
           echo "</table>";
       }
       else {
           echo "0";
       }
       $con-> close();

        ?>
	</table> 
	</body> 
	</html>
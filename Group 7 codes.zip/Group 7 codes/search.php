<?php

// php code to search data in mysql database and set it in input text

if(isset($_POST['search']))
{
    // id to search
    $id = $_POST['id'];
    
    // connect to mysql
    $connect = mysqli_connect("localhost", "root", "","login_sample_db");
    
    // mysql search query
    $query = "SELECT `user_name` FROM `users` WHERE `id` = $id LIMIT 1";
    
    $result = mysqli_query($connect, $query);
    
    // if id exist 
    // show data in inputs
    if(mysqli_num_rows($result) > 0)
    {
      while ($row = mysqli_fetch_array($result))
      {
        $fname = $row['user_name'];
       
      }  
    }
    
    // if the id not exist
    // show a message and clear inputs
    else {
        echo "Undifined ID";
            $fname = "";
         
    }
    
    
    mysqli_free_result($result);
    mysqli_close($connect);
    
}

// in the first time inputs are empty
else{
    $fname = "";
    
}


?>

<!DOCTYPE html>

<html>
    <style>
        @import url(https://fonts.googleapis.com/css?family=Roboto:400,500,300,700);
body{
  background: -webkit-linear-gradient(left, #E10078, #5DC0CD);
  background: linear-gradient(to right, #E10078, #5DC0CD);
  font-family: 'Roboto', sans-serif;
}
        </style>

    <head>

        <title> PHP FIND DATA </title>

        <meta charset="UTF-8">

        <meta name="viewport" content="width=device-width, initial-scale=1.0">

    </head>

    <body>
        <h1> Search</h1>

    <form action="search.php" method="post">

        Id:<input type="text" name="id"><br><br>

        User Name:<input type="text" name="user_name" value="<?php echo $fname;?>"><br>
<br>

       

        <input type="submit" name="search" value="Find">

           </form>
<h2><a href="studnet_list.php">Click here to Back</a></h2>
    </body>

</html>

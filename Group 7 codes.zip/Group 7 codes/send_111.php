<?php  


if (isset($_POST['mark']) && isset($_POST['id'])) {
	include 'db_conn_2.php ';

	function validate($data){
       $data = trim($data);
	   $data = stripslashes($data);
	   $data = htmlspecialchars($data);
	   return $data;
	}

	$mark = validate($_POST['mark']);
	$id = validate($_POST['id']);

	if (empty($mark) || empty($id)) {
		header("Location: index_2.php");
	}else {

		$sql = "INSERT INTO SUB_M_111( mark, id) VALUES('$mark', '$id')";
		$res = mysqli_query($conn, $sql);

		if ($res) {
			echo "Your have submitted successfully!";
		}else {
			echo "Your message could not be sent!";
		}
	}

}else {
	header("Location: index_2_111.php");
}
?>
<html>
	<body>
		<p><a href="index_2_111.php">Back</a></p>
</body>
</html>
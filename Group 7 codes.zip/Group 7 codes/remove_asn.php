<html>
    <head>
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia">
<style>

html {
  box-sizing: border-box;
}

*,
*:before,
*:after {
  box-sizing: inherit;
}

body {
  margin: 0;
  min-height: 100vh;
  font-size: 1rem;
  line-height: 1.25;
  font-family: "Sofia", sans-serif;
  background-color: #18222d;
}

.grid {
  width: 100%;
  max-width: 60rem;
  margin-left: auto;
  margin-right: auto;

  display: flex;
  -webkit-box-orient: horizontal;
  -webkit-box-direction: normal;
  flex-direction: row;
  flex-wrap: wrap;
}

.grid-block {
  width: 50%;
  min-height: 11.25rem;
  padding: 1rem;
}

.image-grid {
  -webkit-transform: rotateX(45deg) rotateZ(45deg);
  transform: rotateX(45deg) rotateZ(45deg);
  -webkit-perspective: 1000px;
  perspective: 1000px;
}

.image-grid .tile-link:hover .tile-img {
  top: -1rem;
  left: -1rem;
}

.image-grid .tile-img {
  position: relative;
  top: 0;
  left: 0;
  -webkit-transition-property: opacity, top, left, box-shadow;
  transition-property: opacity, top, left, box-shadow;
}

.tile-link {
  display: block;
}

.tile-link:hover .tile-img {
  opacity: 1;
}

.tile-link:hover .tile-img-link {
  display: block;
}

.tile-link:hover .tile-img-link:hover .tile-img {
  opacity: 0.5;
}

.tile-img {
  display: block;
  width: 100%;
  height: auto;
  opacity: 1;
  -webkit-transition-property: opacity;
  transition-property: opacity;
  -webkit-transition-duration: 0.125s;
  transition-duration: 0.125s;
  -webkit-transition-timing-function: ease-in;
  transition-timing-function: ease-in;
}
.tile-link:hover .tile-img1 {
    
  box-shadow: 5px 5px rgba(244, 170, 200, 0.4),
    10px 10px rgba(244, 170, 200, 0.3), 15px 15px rgba(244, 170, 200, 0.2),
    20px 20px rgba(244, 170, 200, 0.1), 25px 25px rgba(244, 170, 200, 0.05);
}

.tile-link:hover .tile-img2 {
  box-shadow: 5px 5px rgba(45, 186, 233, 0.4), 10px 10px rgba(45, 186, 233, 0.3),
    15px 15px rgba(45, 186, 233, 0.2), 20px 20px rgba(45, 186, 233, 0.1),
    25px 25px rgba(45, 186, 233, 0.05);
}

.tile-link:hover .tile-img3 {
  box-shadow: 5px 5px rgba(214, 221, 244, 0.4),
    10px 10px rgba(214, 221, 244, 0.3), 15px 15px rgba(214, 221, 244, 0.2),
    20px 20px rgba(214, 221, 244, 0.1), 25px 25px rgba(214, 221, 244, 0.05);
}

.tile-link:hover .tile-img4 {
  box-shadow: 5px 5px rgba(82, 119, 192, 0.4), 10px 10px rgba(82, 119, 192, 0.3),
    15px 15px rgba(82, 119, 192, 0.2), 20px 20px rgba(82, 119, 192, 0.1),
    25px 25px rgba(82, 119, 192, 0.05);
}

.tile-link:hover .tile-img5 {
  box-shadow: 5px 5px rgba(138, 218, 245, 0.4),
    10px 10px rgba(138, 218, 245, 0.3), 15px 15px rgba(138, 218, 245, 0.2),
    20px 20px rgba(138, 218, 245, 0.1), 25px 25px rgba(138, 218, 245, 0.05);
}

.tile-link:hover .tile-img6 {
  box-shadow: 5px 5px rgba(203, 215, 193, 0.4),
    10px 10px rgba(203, 215, 193, 0.3), 15px 15px rgba(203, 215, 193, 0.2),
    20px 20px rgba(203, 215, 193, 0.1), 25px 25px rgba(203, 215, 193, 0.05);
}

.tile-link:hover .tile-img7 {
  box-shadow: 5px 5px rgba(91, 209, 250, 0.4), 10px 10px rgba(91, 209, 250, 0.3),
    15px 15px rgba(91, 209, 250, 0.2), 20px 20px rgba(91, 209, 250, 0.1),
    25px 25px rgba(91, 209, 250, 0.05);
}

.tile-link:hover .tile-img8 {
  box-shadow: 5px 5px rgba(145, 156, 196, 0.4),
    10px 10px rgba(145, 156, 196, 0.3), 15px 15px rgba(145, 156, 196, 0.2),
    20px 20px rgba(145, 156, 196, 0.1), 25px 25px rgba(145, 156, 196, 0.05);
}

.tile-link:hover .tile-img9 {
  box-shadow: 5px 5px rgba(188, 97, 129, 0.4), 10px 10px rgba(188, 97, 129, 0.3),
    15px 15px rgba(188, 97, 129, 0.2), 20px 20px rgba(188, 97, 129, 0.1),
    25px 25px rgba(188, 97, 129, 0.05);
}

.tile-link:hover .tile-img10 {
  box-shadow: 5px 5px rgba(4, 140, 231, 0.4), 10px 10px rgba(4, 140, 231, 0.3),
    15px 15px rgba(4, 140, 231, 0.2), 20px 20px rgba(4, 140, 231, 0.1),
    25px 25px rgba(4, 140, 231, 0.05);
}
.ABC:hover{
    color: rgb(247, 51, 17);
}
.ABC{
    text-align: center;
    
    color: aliceblue;
}
.AB{
    
    
    color: aliceblue;
}


nav {
  margin: 20px;
  
  margin-top: 40px;
  position: relative;
  width: 200px;
  min-width: 320px;
  height: 200px;
}

nav h2 {
  border-radius: 2px;
  position: relative;
  background: #18222d;
  height: 40px;
  text-transform: uppercase;
  color: ivory;
  font-weight: 200;
  display: flex;
  flex: 1;
  justify-content: center;
  align-items: center;
  box-shadow: 4px 4px 20px -2px rgba(0,0,0,.35);
  transition: all .4s;
}

nav:hover h2{
  transform: translateY(-2px);
  box-shadow: 2px 2px 5px -1px rgba(0,0,0,.35);
 }
nav:hover:active h2{
  transform: translateY(10px);
  box-shadow: 0px -1px 2px 0px rgba(0,0,0,.35);
 }

input {
  position: absolute;
  left: 0;
  top: 0;
  width: 100%;
  z-index: 1;
  opacity: 0;
  cursor: pointer;
  height: 40px;
}

#toggle:checked ~ul {
  height: 0%;
}

nav ul {
  padding-left: 0;
  padding-top: 0;
  margin-top: 0;
  list-style: none;
  overflow: hidden;
  text-align: right;
  margin-bottom: 22px;
  text-align: center;
  transition: all .4s ease-out;
  height: 100%;
  
}
nav ul li {
  border-radius: 200px;
  position: relative;
  display: inline-block;
  margin-left: 35px;
  line-height: 1.5;
  width: 100%;
  margin: 0;
  margin-bottom: 5px;
  background: tomato;
  transition: background 3s;
  box-shadow: 2px 2px 10px -2px rgba(0,0,0,.35);
}

nav ul li:hover {
  background: mediumorchid;
  transition: background .45s;
}

nav ul a {
  display: block;
  color: ivory;
  text-transform: lowercase;
  font-size: 18px;
  font-weight: 200;
  text-decoration: none;
  transition: color .3s;
}


</style>
    </head>
   
    <body>
        
        <nav>
            <h2>Back To   ></h2>
             <input id="toggle" type="checkbox" checked>
          <ul>
          <li><a href="about.php">About</a></li>
    <li><a href="noneed.php">Contact</a></li>
   
    <li><a href="main_menu.php">Main Menu</a></li>
    <li><a href="First_page.php">Log out</a></li>
          </ul>
       </nav>
     <h1 class="ABC">
     Remove ASN
     </h1>
        <div class="grid image-grid">

            <div class="grid-block">
                <h1 class="AB">CSE 110</h1>
              <div class="tile">
                <a class="tile-link" href="del_asn_110.php">
                  <img class="tile-img tile-img1" src="https://lh3.googleusercontent.com/pw/ACtC-3eqDpYXSzQK9Gr8Dm6pRBTXg65teqvPUlndvrG31BEmbHGYSiGja4ZhpI86_b5pYG_nWHZvi0-a2svpmvqtfGHSqLAypliNdl9vI-xGKT0XixvVSzroZ0e7HXFeyVoNyU5XMuMoEzf5f6VgQbmIO2yr=w1384-h791-no" alt="Image">
                </a>
              </div>
            </div>
          
            <div class="grid-block">
                <h1 class="AB">CSE 111</h1>
              <div class="tile">
                <a class="tile-link" href="del_asn_111.php">
                  <img class="tile-img tile-img2" src="https://lh3.googleusercontent.com/pw/ACtC-3eO9L51TGiTghLao-VLNhO_C0egdgv7NfamlpdYbMAKCfXNlkk7WPPcxMJTaU9hO-HNnTqUivtavZ-6iK9mzoq0Qf3kJ5MAcnCoDUqbzd8VzpFKhu3mqDYZBG0KNGVxNHSEUwUiTxCUEFf_yFnNNLL0=w1384-h791-no" alt="Image">
                </a>
              </div>
            </div>
          
            <div class="grid-block">
                <h1 class="AB">CSE 220</h1>
              <div class="tile">
                <a class="tile-link" href="del_asn_220.php">
                  <img class="tile-img tile-img3" src="https://lh3.googleusercontent.com/pw/ACtC-3dhqk2CMZiOyFNPfjfffFIRIp1r9XjSNhfWHXk3gHDNf0hGwwWtXlQbtTf7DBp9t_KnCVull_WGpXNDVRtLkslw1qskUAjbSMEilFituKSeJVKqzVbsTFOeLfvd92nowevb7EGG3Pno37_WfsShZnYP=w1384-h791-no" alt="Image">
                </a>
              </div>
            </div>
          
            <div class="grid-block">
                <h1 class="AB">CSE 221</h1>
              <div class="tile">
                <a class="tile-link" href="del_asn_221.php">
                  <img class="tile-img tile-img4" src="https://lh3.googleusercontent.com/pw/ACtC-3eYKEnL-pUFhF9aCKHKKRNrWEyJJ-7SCD8-EJLpBkVKp6jIHEKvBGiOL0hPW5f6UAcyoxaR06XRDUayk0NaQMxpSWCjnNyqdypHsIzrPfSwQZmOBR4-i3VCc0Ywg9CUmFYv2vs-rbmEmio2-4ZUuokZ=w1384-h791-no" alt="Image">
                </a>
              </div>
            </div>
          
            <div class="grid-block">
                <h1 class="AB">CSE 321</h1>
              <div class="tile">
                <a class="tile-link" href="del_asn_321.php">
                  <img class="tile-img tile-img5" src="https://lh3.googleusercontent.com/pw/ACtC-3ckl0QrFbuW3W6VJ88rW0TeCZYumT9H7ZzN1dW6nrxOcf6mxEYT79iai43_T8i9AbiViFkpJBqVtS6d7loh-IgUwviFhdnkg1U-BNgeBPvstSBHCqWokHbx3EIHTkZFh3QkaTykBxZH7BqYvni2ukTL=w1384-h791-no" alt="Image">
                </a>
              </div>
            </div>
          
            <div class="grid-block">
                <h1 class="AB">CSE 330</h1>
              <div class="tile">
                <a class="tile-link" href="del_asn_330.php">
                  <img class="tile-img tile-img6" src="https://lh3.googleusercontent.com/pw/ACtC-3csXE_23DqssKWd76nUGNa5re7em4ySmZEif2L_jxJBpIV0pV3qHYXQope682nX2Qs04nhMHVZlNNwbUGzz6CWjaywX5VaH5TX2Wrh0iocAk5aRrN2ud7H55mGYdR-z-QEyK5ckiZ4BGZLiSpXe-TmD=w1384-h791-no" alt="Image">
                </a>
              </div>
            </div>
          
            
          
          
          
          </div>
    </body>
</html>
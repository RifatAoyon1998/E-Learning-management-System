<?php
require('db.php');

// Username is root
$user = 'root';
$password = '';

// Database name is geeksforgeeks
$database = 'ABC';

// Server is localhost with
// port number 3306
$servername='localhost:3306';
$mysqli = new mysqli($servername , $user,
				$password, $database);

// Checking for connections
if ($mysqli->connect_error) {
	die('Connect Error (' .
	$mysqli->connect_errno . ') '.
	$mysqli->connect_error);
}

// SQL query to select data from database
// $sql = " SELECT * FROM `crud` WHERE email='science'";
// $result = $mysqli->query($sql);

//About


$sql_about = "SELECT * FROM `crud`";
$result_about = $mysqli->query($sql_about);


// $row_about = $result_about->fetch_assoc();

// $course_user_name=$row_about['name'];
// echo $course_user_name;


$mysqli->close();
?>








<?php
    
 




while($row_about = $result_about->fetch_assoc()){
    $abc=$row_about['name'];
    mkdir($row_about['name']);



    $xyz=$row_about['phone'];
    $yz='/';

     
     $aa= '/Applications/XAMPP/xamppfiles/htdocs/ur/'.$abc.$yz;
     echo $aa;
     echo '----------';
 
    //  mkdir($aa. $row_about['phone']);





}

       
   
           
            ?>

<html>
    <body>
    <a href="admin/dashboard.php">     <h1>Registration Done !</h1></a>
        <body>
    <html>
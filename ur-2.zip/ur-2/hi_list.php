<?php
require('db.php');

// Username is root
$user = 'root';
$password = '';

// Database name is geeksforgeeks
$database = 'ABC';

// Server is localhost with
// port number 3306
$servername='localhost:3306';
$mysqli = new mysqli($servername , $user,
				$password, $database);

// Checking for connections
if ($mysqli->connect_error) {
	die('Connect Error (' .
	$mysqli->connect_errno . ') '.
	$mysqli->connect_error);
}

// SQL query to select data from database
// $sql = " SELECT * FROM `crud` WHERE email='science'";
// $result = $mysqli->query($sql);

//About


$sql_about = "SELECT * FROM `crud`";
$result_about = $mysqli->query($sql_about);


$row_about = $result_about->fetch_assoc();

// $course_user_name=$row_about['name'];
// echo $course_user_name;


$mysqli->close();
?>








<?php
    // function createDirectory($a) {
        // $add = $_POST["add"];
//         $add='CSE250';
// // echo $a;
//         mkdir('/Applications/XAMPP/xamppfiles/htdocs/ur/ayan/'.$add);
        // $aaa=$_GET['name'];
        
        // echo $aaa;
        // mkdir($aaa);
        // echo "<script type = 'text/javascript'>alert('Done!');</script>";
    // }
   
while($row_about = $result_about->fetch_assoc()){
    ?>

    <a href="hi_3.php?name=<?php echo $row_about['name']; ?>">
<h1><?php echo $row_about['name']; ?></h1></a>

<?php
}
       
   
            // createDirectory('ABC');
            ?>
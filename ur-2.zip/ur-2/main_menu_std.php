<?php
require('db.php');
include("auth_session.php");
// Username is root
$user = 'root';
$password = '';

// Database name is geeksforgeeks
$database = 'ABC';

// Server is localhost with
// port number 3306
$servername='localhost:3306';
$mysqli = new mysqli($servername , $user,
				$password, $database);

// Checking for connections
if ($mysqli->connect_error) {
	die('Connect Error (' .
	$mysqli->connect_errno . ') '.
	$mysqli->connect_error);
}

// SQL query to select data from database
// $sql = " SELECT * FROM `crud` WHERE email='science'";
// $result = $mysqli->query($sql);

//About
$aaa = $_SESSION['username'];

$sql_about = " SELECT email FROM `users` WHERE username= '$aaa'";
$result_about = $mysqli->query($sql_about);


$row_about = $result_about->fetch_assoc();


//Courses
$sql = " SELECT * from crud where phone not in (select phone from crud_2 where name='$aaa') and email='science'";
$result = $mysqli->query($sql);

$sql_2 = " SELECT * from crud where phone not in (select phone from crud_2 where name='$aaa') and email='arts'";
$result_2 = $mysqli->query($sql_2);

$sql_3 = " SELECT * from crud where phone not in (select phone from crud_2 where name='$aaa') and email='business'";
$result_3 = $mysqli->query($sql_3);



$sql_enr = " SELECT * FROM `crud_2` WHERE name='$aaa'";
$result_enr = $mysqli->query($sql_enr);

$mysqli->close();
?>



<html>
    <head>

<style>

@import url('https://fonts.googleapis.com/css2?family=Dosis:wght@200;300;400;500;600;700;800&display=swap');

*{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body{
    width: 100%;
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    perspective: 1000px;
    overflow: hidden;
    position: relative;
    background: #212121;
    font-family: 'dosis';
}


.conatiner {
	width: 100%;
	height: 500px;
}
.wrap {
	display: -webkit-box;
	display: -ms-flexbox;
	display: flex;
	-ms-flex-wrap: wrap;
	    flex-wrap: wrap;
	-webkit-box-pack: center;
	    -ms-flex-pack: center;
	        justify-content: center;
	-webkit-box-align: center;
	    -ms-flex-align: center;
	        align-items: center;
	-webkit-box-orient: horizontal;
	-webkit-box-direction: normal;
	    -ms-flex-direction: row;
	        flex-direction: row;
}



.box {
	margin: 10px;
	width: 300px;
	height: 490px;
	text-align: center;
	border-radius: 3px;
	-webkit-transition: 200ms ease-in-out;
	-o-transition: 200ms ease-in-out;
	transition: 200ms ease-in-out;
	-webkit-box-shadow: 0 0 15px rgba(0,0,0,0.3);
	        box-shadow: 0 0 15px rgba(0,0,0,0.3);
}
.box:hover {
	margin-bottom: -10px;
	-webkit-box-shadow: 0 0 5px rgba(0,0,0,0.7);
	        box-shadow: 0 0 5px rgba(0,0,0,0.7);
}
.box h1 {
	color: #fff;
	padding: 30px;
	margin-top: 100px;
	text-align: center;
	font-weight: 100;
	font-size: 25px;
	/* background: rgba(0,0,0,0.8); */
	/* -webkit-box-shadow: 0 0 30px rgba(0,0,0,0.7);
	        box-shadow: 0 0 30px rgba(0,0,0,0.8); */
}

.date h4 {
	color: #fff;
	font-weight: 300;
	text-align: center;
	letter-spacing: 3px;
	text-shadow: 0 0 3px rgba(0,0,0,0.9);
}
.poster {
	width: 130px;
	height:130px;
	margin: 120px auto;
	position: relative;
	border-radius: 100px;
}
.poster h4 {
	top: 16px;
	color: #fff;
	position: relative;
	font-size: 80px;
	text-align: center;
	font-weight: 100;
}
.one {
	background: url('https://source.unsplash.com/900x920');
	background-repeat: no-repeat;
	background-size: cover;
	background-position: center;
}

.two {
	background: url('https://source.unsplash.com/820x900');
	background-repeat: no-repeat;
	background-size: cover;
	background-position: center;
}
.three {
	background: url('https://source.unsplash.com/500x500');
	background-repeat: no-repeat;
	background-size: cover;
	background-position: center;
}

.five {
	background: url('https://source.unsplash.com/550x520');
	background-repeat: no-repeat;
	background-size: cover;
	background-position: center;
}
.six {
	background: url('https://source.unsplash.com/660x630');
	background-repeat: no-repeat;
	background-size: cover;
	background-position: center;
}
.seven {
	background: url('https://source.unsplash.com/700x770');
	background-repeat: no-repeat;
	background-size: cover;
	background-position: center;
}
.eight {
	background: url('https://source.unsplash.com/880x820');
	background-repeat: no-repeat;
	background-size: cover;
	background-position: center;
}
.nine {
	background: url('https://source.unsplash.com/898x820');
	background-repeat: no-repeat;
	background-size: cover;
	background-position: center;
}
.ten {
	background: url('https://source.unsplash.com/8998x920');
	background-repeat: no-repeat;
	background-size: cover;
	background-position: center;
}
.eleven {
	background: url('https://source.unsplash.com/898x960');
	background-repeat: no-repeat;
	background-size: cover;
	background-position: center;
}

.tlv {
	background: url('https://source.unsplash.com/999x888');
	background-repeat: no-repeat;
	background-size: cover;
	background-position: center;
}

.thirteen {
	background: url('https://source.unsplash.com/1000x777');
	background-repeat: no-repeat;
	background-size: cover;
	background-position: center;
}

.ftn {
	background: url('https://source.unsplash.com/2000x777');
	background-repeat: no-repeat;
	background-size: cover;
	background-position: center;
}

.fith {
	background: url('https://source.unsplash.com/2000x1000');
	background-repeat: no-repeat;
	background-size: cover;
	background-position: center;
}
.sith {
	background: url('https://source.unsplash.com/3000x1000');
	background-repeat: no-repeat;
	background-size: cover;
	background-position: center;
}

.sevth {
	background: url('https://source.unsplash.com/9000x9000');
	background-repeat: no-repeat;
	background-size: cover;
	background-position: center;
}

/* POSTER*/
.p1 {
	background: #2b5876;  /* fallback for old browsers */
	background: -webkit-linear-gradient(to right, #4e4376, #2b5876);  /* Chrome 10-25, Safari 5.1-6 */
	background: -webkit-gradient(linear, left top, right top, from(#4e4376), to(#2b5876));
	background: -webkit-linear-gradient(left, #4e4376, #2b5876);
	background: -o-linear-gradient(left, #4e4376, #2b5876);
	background: linear-gradient(to right, #4e4376, #2b5876); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
	-webkit-box-shadow: 0 0 20px darkblue;
	        box-shadow: 0 0 20px darkblue;
}

.p2 {
	background: #f857a6;  /* fallback for old browsers */
	background: -webkit-linear-gradient(to right, #ff5858, #f857a6);  /* Chrome 10-25, Safari 5.1-6 */
	background: -webkit-gradient(linear, left top, right top, from(#ff5858), to(#f857a6));
	background: -webkit-linear-gradient(left, #ff5858, #f857a6);
	background: -o-linear-gradient(left, #ff5858, #f857a6);
	background: linear-gradient(to right, #ff5858, #f857a6); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
	-webkit-box-shadow: 0 0 20px #fa3380;
	        box-shadow: 0 0 20px #fa3380;
}

.p3 {
	background: #4776E6;  /* fallback for old browsers */
	background: -webkit-linear-gradient(to right, #8E54E9, #4776E6);  /* Chrome 10-25, Safari 5.1-6 */
	background: -webkit-gradient(linear, left top, right top, from(#8E54E9), to(#4776E6));
	background: -webkit-linear-gradient(left, #8E54E9, #4776E6);
	background: -o-linear-gradient(left, #8E54E9, #4776E6);
	background: linear-gradient(to right, #8E54E9, #4776E6); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
	-webkit-box-shadow: 0 0 20px lightblue;
	        box-shadow: 0 0 20px lightblue;
}

.p4 {
	background: #1FA2FF;  /* fallback for old browsers */
	background: -webkit-linear-gradient(to right, #A6FFCB, #12D8FA, #1FA2FF);  /* Chrome 10-25, Safari 5.1-6 */
	background: -webkit-gradient(linear, left top, right top, from(#A6FFCB), color-stop(#12D8FA), to(#1FA2FF));
	background: -webkit-linear-gradient(left, #A6FFCB, #12D8FA, #1FA2FF);
	background: -o-linear-gradient(left, #A6FFCB, #12D8FA, #1FA2FF);
	background: linear-gradient(to right, #A6FFCB, #12D8FA, #1FA2FF); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
	-webkit-box-shadow: 0 0 20px skyblue;
	        box-shadow: 0 0 20px skyblue;
}


.p5 {
	background: #AA076B;  /* fallback for old browsers */
	background: -webkit-linear-gradient(to right, #61045F, #AA076B);  /* Chrome 10-25, Safari 5.1-6 */
	background: -webkit-gradient(linear, left top, right top, from(#61045F), to(#AA076B));
	background: -webkit-linear-gradient(left, #61045F, #AA076B);
	background: -o-linear-gradient(left, #61045F, #AA076B);
	background: linear-gradient(to right, #61045F, #AA076B); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
	-webkit-box-shadow: 0 0 20px purple;
	        box-shadow: 0 0 20px purple;
}

.p6 {
	background: #DA22FF;  /* fallback for old browsers */
	background: -webkit-linear-gradient(to right, #9733EE, #DA22FF);  /* Chrome 10-25, Safari 5.1-6 */
	background: -webkit-gradient(linear, left top, right top, from(#9733EE), to(#DA22FF));
	background: -webkit-linear-gradient(left, #9733EE, #DA22FF);
	background: -o-linear-gradient(left, #9733EE, #DA22FF);
	background: linear-gradient(to right, #9733EE, #DA22FF); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
	-webkit-box-shadow: 0 0 20px violet;
	        box-shadow: 0 0 20px violet;
}

.p7 {
	background: #02AAB0;  /* fallback for old browsers */
	background: -webkit-linear-gradient(to right, #00CDAC, #02AAB0);  /* Chrome 10-25, Safari 5.1-6 */
	background: -webkit-gradient(linear, left top, right top, from(#00CDAC), to(#02AAB0));
	background: -webkit-linear-gradient(left, #00CDAC, #02AAB0);
	background: -o-linear-gradient(left, #00CDAC, #02AAB0);
	background: linear-gradient(to right, #00CDAC, #02AAB0); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
	-webkit-box-shadow: 0 0 20px lightgreen;
	        box-shadow: 0 0 20px lightgreen;
}
.p8 {
	background: #5433FF;  /* fallback for old browsers */
	background: -webkit-linear-gradient(to right, #A5FECB, #20BDFF, #5433FF);  /* Chrome 10-25, Safari 5.1-6 */
	background: -webkit-gradient(linear, left top, right top, from(#A5FECB), color-stop(#20BDFF), to(#5433FF));
	background: -webkit-linear-gradient(left, #A5FECB, #20BDFF, #5433FF);
	background: -o-linear-gradient(left, #A5FECB, #20BDFF, #5433FF);
	background: linear-gradient(to right, #A5FECB, #20BDFF, #5433FF); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
	-webkit-box-shadow: 0 0 20px lightblue;
	        box-shadow: 0 0 20px lightblue;
}
.p9 {
	background: #2b5876;  /* fallback for old browsers */
	background: -webkit-linear-gradient(to right, #fa3, #fa3380);  /* Chrome 10-25, Safari 5.1-6 */
	background: -webkit-gradient(linear, left top, right top, from(#fa3), to(#fa3380));
	background: -webkit-linear-gradient(left, #fa3, #fa3380);
	background: -o-linear-gradient(left, #fa3, #fa3380);
	background: linear-gradient(to right, #fa3, #fa3380); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
	-webkit-box-shadow: 0 0 20px #fa3380;
	        box-shadow: 0 0 20px #fa3380;
}

.p10 {
	background: #2b5876;  /* fallback for old browsers */
	background: -webkit-linear-gradient(to right, deepskyblue, lightblue);  /* Chrome 10-25, Safari 5.1-6 */
	background: -webkit-gradient(linear, left top, right top, from(deepskyblue), to(lightblue));
	background: -webkit-linear-gradient(left, deepskyblue, lightblue);
	background: -o-linear-gradient(left, deepskyblue, lightblue);
	background: linear-gradient(to right, deepskyblue, lightblue); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
	-webkit-box-shadow: 0 0 20px darkblue;
	        box-shadow: 0 0 20px darkblue;
}

.p11 {
	background: #F2994A;  /* fallback for old browsers */
	background: -webkit-linear-gradient(to right, #F2C94C, #F2994A);  /* Chrome 10-25, Safari 5.1-6 */
	background: -webkit-gradient(linear, left top, right top, from(#F2C94C), to(#F2994A));
	background: -webkit-linear-gradient(left, #F2C94C, #F2994A);
	background: -o-linear-gradient(left, #F2C94C, #F2994A);
	background: linear-gradient(to right, #F2C94C, #F2994A); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
	-webkit-box-shadow: 0 0 20px lightyellow;
	        box-shadow: 0 0 20px lightyellow;
}

.p12 {
	background: #A770EF;  /* fallback for old browsers */
	background: -webkit-linear-gradient(to right, #FDB99B, #CF8BF3, #A770EF);  /* Chrome 10-25, Safari 5.1-6 */
	background: -webkit-gradient(linear, left top, right top, from(#FDB99B), color-stop(#CF8BF3), to(#A770EF));
	background: -webkit-linear-gradient(left, #FDB99B, #CF8BF3, #A770EF);
	background: -o-linear-gradient(left, #FDB99B, #CF8BF3, #A770EF);
	background: linear-gradient(to right, #FDB99B, #CF8BF3, #A770EF); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
	-webkit-box-shadow: 0 0 20px purple;
	        box-shadow: 0 0 20px purple;
}

.p13 {
	background: #f4c4f3;  /* fallback for old browsers */
	background: -webkit-linear-gradient(to right, #fc67fa, #f4c4f3);  /* Chrome 10-25, Safari 5.1-6 */
	background: -webkit-gradient(linear, left top, right top, from(#fc67fa), to(#f4c4f3));
	background: -webkit-linear-gradient(left, #fc67fa, #f4c4f3);
	background: -o-linear-gradient(left, #fc67fa, #f4c4f3);
	background: linear-gradient(to right, #fc67fa, #f4c4f3); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
	-webkit-box-shadow: 0 0 20px pink;
	        box-shadow: 0 0 20px pink;
}
.p14 {
	background: #00c3ff;  /* fallback for old browsers */
	background: -webkit-linear-gradient(to right, #ffff1c, #00c3ff);  /* Chrome 10-25, Safari 5.1-6 */
	background: -webkit-gradient(linear, left top, right top, from(#ffff1c), to(#00c3ff));
	background: -webkit-linear-gradient(left, #ffff1c, #00c3ff);
	background: -o-linear-gradient(left, #ffff1c, #00c3ff);
	background: linear-gradient(to right, #ffff1c, #00c3ff); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
	-webkit-box-shadow: 0 0 20px olive;
	        box-shadow: 0 0 20px olive;
}
.p15 {
	background: #5614B0;  /* fallback for old browsers */
	background: -webkit-linear-gradient(to right, #DBD65C, #5614B0);  /* Chrome 10-25, Safari 5.1-6 */
	background: -webkit-gradient(linear, left top, right top, from(#DBD65C), to(#5614B0));
	background: -webkit-linear-gradient(left, #DBD65C, #5614B0);
	background: -o-linear-gradient(left, #DBD65C, #5614B0);
	background: linear-gradient(to right, #DBD65C, #5614B0); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
	-webkit-box-shadow: 0 0 20px olive;
	        box-shadow: 0 0 20px olive;
}

.p16 {
	background: #fc00ff;  /* fallback for old browsers */
	background: -webkit-linear-gradient(to right, #00dbde, #fc00ff);  /* Chrome 10-25, Safari 5.1-6 */
	background: -webkit-gradient(linear, left top, right top, from(#00dbde), to(#fc00ff));
	background: -webkit-linear-gradient(left, #00dbde, #fc00ff);
	background: -o-linear-gradient(left, #00dbde, #fc00ff);
	background: linear-gradient(to right, #00dbde, #fc00ff); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
	-webkit-box-shadow: 0 0 20px olive;
	        box-shadow: 0 0 20px olive;
}


/*  FOLLOW*/
.Follow {	  background:url("https://pbs.twimg.com/profile_images/959092900708544512/v4Db9QRv_bigger.jpg")no-repeat center / contain;
	width: 50px;
	height: 50px;
	bottom: 9px;
	right: 20px;
	display:block;
	position:fixed;
	border-radius:50%;
	z-index:999;
	animation:  rotation 10s infinite linear;
	}

@-webkit-keyframes rotation {
		from {
				-webkit-transform: rotate(0deg);
		}
		to {
				-webkit-transform: rotate(359deg);
		}
}

.navbar{
    width: 100%;
    height: 60px;
    position: fixed;
    top: 0;
    left: 0;
    padding: 0 10vw;
    display: flex;
    justify-content: space-between;
    align-items: center;
    z-index: 9;
}

.brand{
    font-weight: 500;
    color: #FFF;
    text-transform: capitalize;
    font-size: 25px;
    letter-spacing: 2px;
}

.toggle-btn{
    position: relative;
    width: 50px;
    height: 50px;
    cursor: pointer;
}

.toggle-btn span{
    position: absolute;
    top: 25%;
    left: 0;
    transform: translateY(-50%);
    width: 100%;
    height: 3px;
    background: #FFF;
    transition: 1s;
}

.toggle-btn span:nth-child(2){
    top: 50%;
    width: 70%;
}

.toggle-btn span:nth-child(3){
    top: 75%;
    width: 40%;
}

.toggle-btn.active span:nth-child(2){
    display: none;
}

.toggle-btn.active span:nth-child(1){
    transform: rotate(45deg);
    top: 50%
}

.toggle-btn.active span:nth-child(3){
    transform: rotate(-45deg);
    top: 50%;
    width: 100%;
}

.page-container{
    position: relative;
    width: 100%;
    height: 100%;
    -webkit-box-reflect: below 20px linear-gradient(to bottom, rgba(0, 0, 0, 0), rgba(0, 0, 0, 0.4));
    transition: 1s;
    left: 0;
}

.overlay{
    position: fixed;
    bottom: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: #212121;
    z-index: 3;
}

.page{
    position: absolute;
    width: 100%;
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 1;
    pointer-events: none;
    opacity: 0;
}

.page.active{
    opacity: 1;
    pointer-events: all;
}

.page.home{
    /* background-image: url(https://imagesvc.meredithcorp.io/v3/mm/image?url=https%3A%2F%2Fstatic.onecms.io%2Fwp-content%2Fuploads%2Fsites%2F28%2F2017%2F02%2Feiffel-tower-paris-france-EIFFEL0217.jpg&q=60); */
    background: #2a364f;
    background-size: cover;
}

.page.project{
    /* background-image: url(https://i.ytimg.com/vi/HrBFLlGrKPQ/maxresdefault.jpg); */
    background: #2a364f;
    background-size: cover;
}

.page.about{
    /* background-image: url(https://corp.changegroup.com/sites/default/cache/file/A3934901-67AD-4F4F-A0F533D877BBC2BF.jpg); */
    background: #2a364f;
    background-size: cover;
}

.page .title{
    font-size: 100px;
    color: #FFF;
    text-transform: uppercase;
    -webkit-text-stroke: 2px #000;
    font-weight: 700;
}

.page-container.active{
    left: -10%;
    transform: rotateY(45deg) scale(0.5);
}

.nav-list{
    position: absolute;
    top: 50%;
    right: 10vw;
    transform: translateY(-50%);
    transition: 1s;
    opacity: 0;
}

.link{
    position: relative;
    color: #fff;
    text-transform: capitalize;
    font-size: 20px;
    padding: 10px;
    transition: .5s;
    letter-spacing: 2px;
    list-style: none;
    cursor: pointer;
    font-weight: 700;
}

.link:hover{
    opacity: 0.8;
    color: rgb(255, 98, 98);
    transform: translateX(-20px);
}

.nav-list.show{
    opacity: 1;
}

@keyframes slide{
    100%{
        left: 100%;
    }
}

@media (max-width: 996px){
  body::after{
    content: 'See in 0.5x scale';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: #000;
    z-index: 99999;
    color: #fff;
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 20px;
  }
}


</style>
    </head>
    <body>
        <nav class="navbar">
            <p class="brand">Apprende.com</p>
            <div class="toggle-btn">
                <span></span>
                <span></span>
                <span></span>
                
				

            </div>
        </nav>
    
        <ul class="nav-list">
            <li class="link">Science</li>
            <li class="link">Arts</li>
			<li class="link">Business</li>
            <li class="link">About</li>
			<li class="link">Enrolled Courses</li>
			
        </ul>
    
        <header class="page-container">
            <span class="overlay"></span>
            <section class="page home active">
                	
<!-- <p>Science<br>Busisness<br>Arts</p> -->

<div class="conatiner">
<div class="wrap">
	
<?php
                // LOOP TILL END OF DATA
                while($rows=$result->fetch_assoc())
                {
            ?>



	<div class="box one">
		<!-- <div class="date">
			<h4>6/29/18</h4>
		</div> -->

		<!-- <p class="card-text"></p> -->
		<a href="ok_2.php?name=<?php echo $rows['phone'];?>">	<h1><?php echo $rows['phone'];?> </h1>
		<div class="poster p1">
			<p></p>
			<h1>Enroll<br><small>BDT:<?php echo $rows['city'];?></small></h1>
			
		</div></a>
		

	</div>
	
	
	<?php
                }
            ?> 

	


	
</div>
</div>
            </section>
            <section class="page project">
                
     

			<div class="conatiner">
<div class="wrap">
	
<?php
                // LOOP TILL END OF DATA
                while($rows=$result_2->fetch_assoc())
                {
            ?>



	<div class="box one">
		<!-- <div class="date">
			<h4>6/29/18</h4>
		</div> -->

		<!-- <p class="card-text"></p> -->
		<a href="ok_2.php?name=<?php echo $rows['phone'];?>">
		<h1><?php echo $rows['phone'];
		
		?> </h1>
		<div class="poster p1">
			<p></p>
			<h1>Enroll<br><small>BDT:<?php echo $rows['city'];?></small></h1>
			
		</div>
				</a>

	</div>
	
	
	<?php
                }
            ?> 

	


	
</div>
</div>



            </section>
            <section class="page about">
                

			<div class="conatiner">
<div class="wrap">
	
<?php
                // LOOP TILL END OF DATA
                while($rows=$result_3->fetch_assoc())
                {
            ?>



	<div class="box one">
		<!-- <div class="date">
			<h4>6/29/18</h4>
		</div> -->

		<!-- <p class="card-text"></p> -->

		<a href="ok_2.php?name=<?php echo $rows['phone'];?>">
		<h1><?php echo $rows['phone'];?> </h1>
		<div class="poster p1">
			<p></p>
			<h1>Enroll<br><small>BDT:<?php echo $rows['city'];?></small></h1>
			
		</div>
		
				</a>
	</div>
	
	
	<?php
                }
            ?> 

	


	
</div>
</div>



            </section>


			<section class="page about">
                

			<div class="form">
        <h1>Hey, <?php echo $_SESSION['username']; ?>!</h1>
<h1> Email:
<?php  




    echo $row_about['email'] ;
  

?>


			</h1>
<br>

<Button><a href="info_update_s.php">Edit Your Info</a></Button>
        <br>
        <Button><a href="logout.php">Logout</a></Button>
    </div>
	
	
	
				</section>


<section>

<div class="conatiner">
<div class="wrap">
	
<?php
                // LOOP TILL END OF DATA
                while($rows=$result_enr->fetch_assoc())
                {
            ?>



	<div class="box one">
		<!-- <div class="date">
			<h4>6/29/18</h4>
		</div> -->

		<!-- <p class="card-text"></p> -->

		
		<a href="hello_a.php?name=<?php echo $rows['phone'];?>">
		<h1><?php echo $rows['phone'];?> </h1>
		<div class="poster p1">
			<p></p>
			<h1>Marks:<br><small><?php echo $rows['city'];?></small></h1>
			
		</div>
		
				</a>
	</div>
	
	
	<?php
                }
            ?> 

	


	
</div>
</div>
			</section>

        </header>
      <script>
          const container = document.querySelector('.page-container');
const pages = [...document.querySelectorAll('.page')];
const toggleBtn = document.querySelector('.toggle-btn');
const ul = document.querySelector('.nav-list');
const overlay = document.querySelector('.overlay');
const links = [...document.querySelectorAll('.link')];

let currentPageIndex = 0;

toggleBtn.addEventListener('click', () => {
    toggleBtn.classList.toggle('active');
    container.classList.toggle('active');
    ul.classList.toggle('show');
})

const changePage = (i) => {
    overlay.style.animation = `slide 1s linear 1`;
    setTimeout(() => {
        pages[currentPageIndex].classList.remove('active');
        pages[i].classList.add('active');
        currentPageIndex = i;
    }, 500);
    setTimeout(() => {
        overlay.style.animation = null;
    }, 1000);
}

links.forEach((item, i) => {
    item.addEventListener('click', () => {
        changePage(i);
    })
})
      </script>
    </body>
</html>
    

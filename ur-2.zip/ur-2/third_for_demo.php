<?php
require('db.php');
include("auth_session.php");
// Username is root
$user = 'root';
$password = '';

// Database name is geeksforgeeks
$database = 'ABC';

// Server is localhost with
// port number 3306
$servername='localhost:3306';
$mysqli = new mysqli($servername , $user,
				$password, $database);

// Checking for connections
if ($mysqli->connect_error) {
	die('Connect Error (' .
	$mysqli->connect_errno . ') '.
	$mysqli->connect_error);
}

// SQL query to select data from database
// $sql = " SELECT * FROM `crud` WHERE email='science'";
// $result = $mysqli->query($sql);

//About
$aaa = $_SESSION['username'];

$sql_about = " SELECT email FROM `users` WHERE username= '$aaa'";
$result_about = $mysqli->query($sql_about);

$name=$_GET['p']; 

$row_about = $result_about->fetch_assoc();


//Courses
$sql = " SELECT * from crud where phone not in (select phone from crud_2 where name='$aaa') and email='science'";
$result = $mysqli->query($sql);

$sql_2 = " SELECT * from crud where phone not in (select phone from crud_2 where name='$aaa') and email='arts'";
$result_2 = $mysqli->query($sql_2);

$sql_3 = " SELECT * from crud where phone not in (select phone from crud_2 where name='$aaa') and email='business'";
$result_3 = $mysqli->query($sql_3);



$sql_enr = " SELECT * FROM `crud` WHERE phone='$name'";
$result_enr = $mysqli->query($sql_enr);
$rows=$result_enr->fetch_assoc();

$xyz="demo".$name;

$mysqli->close();
?>

<html>
    <body>

 <a href="demo_video.php?p=<?php echo $xyz; ?>">   <p>Video <?php echo $xyz; ?></p></a>

</body>
            </html>

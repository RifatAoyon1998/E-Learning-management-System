<?php
include("auth_session.php");
// Username is root
$user = 'root';
$password = '';

// Database name is geeksforgeeks
$database = 'ABC';

// Server is localhost with
// port number 3306
$servername='localhost:3306';
$mysqli = new mysqli($servername , $user,
				$password, $database);

// Checking for connections
if ($mysqli->connect_error) {
	die('Connect Error (' .
	$mysqli->connect_errno . ') '.
	$mysqli->connect_error);
}

// SQL query to select data from database
// $sql = " SELECT * FROM `crud` WHERE email='science'";
// $result = $mysqli->query($sql);

//About
$aaa = $_SESSION['username'];

$sql_about = " SELECT * FROM `users` WHERE username= '$aaa'";
$result_about = $mysqli->query($sql_about);


$row_about = $result_about->fetch_assoc();

?>


<html>
    <head>

<style>
    
    * {  
      margin: 0;  
      padding: 0;  
      box-sizing: border-box;  
      font-family: "Poppins", sans-serif;  
 }  
 body {  
      overflow: hidden;  
 }  
 section {  
      display: flex;  
      min-height: 100vh;  
      align-items: center;  
      justify-content: center;  
      background: linear-gradient(to bottom, #f7f7fe, #dff1ff);  
 }  
 section .colour {  
      position: absolute;  
      filter: blur(150px);  
 }  
 section .colour:nth-child(1) {  
      top: -350px;  
      width: 600px;  
      height: 800px;  
      background: #bf4ad4;  
 }  
 section .colour:nth-child(2) {  
      left: 100px;  
      width: 500px;  
      height: 500px;  
      bottom: -150px;  
      background: #ffa500;  
 }  
 section .colour:nth-child(3) {  
      right: 100px;  
      bottom: 50px;  
      width: 300px;  
      height: 300px;  
      background: #2b67f3;  
 }  
 .box {  
      position: relative;  
 }  
 .box .square {  
      position: absolute;  
      border-radius: 10px;  
      backdrop-filter: blur(5px);  
      background: rgba(255, 255, 255, 0.1);  
      animation-delay: calc(-1s * var(--i));  
      animation: animate 10s linear infinite;  
      box-shadow: 0 25px 45px rgba(0, 0, 0, 0.1);  
      border: 1px solid rgba(255, 255, 255, 0.5);  
      border-right: 1px solid rgba(255, 255, 255, 0.2);  
      border-bottom: 1px solid rgba(255, 255, 255, 0.2);  
 }  
 @keyframes animate {  
      0%,  
      100% {  
           transform: translateY(-40px);  
      }  
      50% {  
           transform: translateY(40px);  
      }  
 }  
 .box .square:nth-child(1) {  
      top: -50px;  
      left: -60px;  
      width: 100px;  
      height: 100px;  
 }  
 .box .square:nth-child(2) {  
      z-index: 2;  
      top: 150px;  
      left: -100px;  
      width: 120px;  
      height: 120px;  
 }  
 .box .square:nth-child(3) {  
      z-index: 2;  
      width: 80px;  
      height: 80px;  
      right: -50px;  
      bottom: -60px;  
 }  
 .box .square:nth-child(4) {  
      left: 100px;  
      width: 50px;  
      height: 50px;  
      bottom: -80px;  
 }  
 .box .square:nth-child(5) {  
      top: -80px;  
      left: 140px;  
      width: 60px;  
      height: 60px;  
 }  
 .container {  
      width: 400px;  
      display: flex;  
      min-height: 400px;  
      position: relative;  
      border-radius: 10px;  
      align-items: center;  
      justify-content: center;  
      backdrop-filter: blur(5px);  
      background: rgba(255, 255, 255, 0.1);  
      box-shadow: 0 25px 45px rgba(0, 0, 0, 0.1);  
      border: 1px solid rgba(255, 255, 255, 0.5);  
      border-right: 1px solid rgba(255, 255, 255, 0.2);  
      border-bottom: 1px solid rgba(255, 255, 255, 0.2);  
 }  
 .form {  
    height: 520px;
    width: 400px;  
      padding: 40px;  
      position: relative;  
 }  
 .form h2 {  
      color: rgb(15, 15, 15);  
      font-size: 24px;  
      font-weight: 600;  
      position: relative;  
      letter-spacing: 1px;  
      margin-bottom: 40px;  
 }  
 .form h2::before {  
      left: 0;  
      width: 80px;  
      height: 4px;  
      content: "";  
      bottom: -10px;  
      background: rgb(8, 8, 8);  
      position: absolute;  
 }  
 .form .input__box {  
      width: 100%;  
      margin-top: 20px;  
 }  
 .form .input__box input {  
      width: 100%;  
      color: #fff;  
      border: none;  
      outline: none;  
      font-size: 16px;  
      padding: 10px 20px;  
      letter-spacing: 1px;  
      border-radius: 35px;  
      background: rgba(255, 255, 255, 0.2);  
      border: 1px solid rgba(255, 255, 255, 0.5);  
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);  
      border-right: 1px solid rgba(255, 255, 255, 0.2);  
      border-bottom: 1px solid rgba(255, 255, 255, 0.2);  
 }  
 .form::placeholder {  
      color: #fff;  
 }  
 .form .input__box input[type="submit"] {  
      color: #666;  
      cursor: pointer;  
      background: #fff;  
      max-width: 100px;  
      font-weight: 600;  
      margin-bottom: 20px;  
 }  
 .forget {  
      color: rgb(5, 5, 5);  
      margin-top: 5px;  
 }  
 .forget a {  
      color: rgb(10, 10, 10);  
      font-weight: 600;  
      text-decoration: none;  
 }  
h1{
    margin-top: 3pc;
}
</style>
    </head>
    <body>
   <h1>Payment for Course</h1>
    <?php
    require('db.php');
    // When form submitted, insert values into the database.
    if (isset($_REQUEST['username'])) {
        // removes backslashes
        $username = stripslashes($_REQUEST['username']);
        //escapes special characters in a string
        $username = mysqli_real_escape_string($con, $username);
        $email    = stripslashes($_REQUEST['email']);
        $email    = mysqli_real_escape_string($con, $email);

        $number    = stripslashes($_REQUEST['number']);
        $number    = mysqli_real_escape_string($con, $number);

        $pay    = stripslashes($_REQUEST['pay']);
        $pay    = mysqli_real_escape_string($con, $pay);

        $T_id    = stripslashes($_REQUEST['T_id']);
        $T_id    = mysqli_real_escape_string($con, $T_id);

     //    $password = stripslashes($_REQUEST['password']);
     //    $password = mysqli_real_escape_string($con, $password);
     //    $create_datetime = date("Y-m-d H:i:s");
        $query    = "INSERT into `payment_std` (username,email ,number, pay, T_id)
     VALUES ('$username','$email', '$number', '$pay ','$T_id')";
                      
        $result   = mysqli_query($con, $query);
        if ($result) {
          $ab= '/Applications/XAMPP/xamppfiles/htdocs/ur/';
          $abc=$ab.$username.$email;
          mkdir($abc);
         
          

        } else {
            echo "<div class='form'>
                  <h3>Required fields are missing.</h3><br/>
                  <p class='link'>Click here to <a href='registration_471.php'>registration</a> again.</p>
                  </div>";
        }
    } else {
?>


<section>  

<div class="colour"></div>  
    <div class="colour"></div>  
    <div class="colour"></div>  
    <div class="box">  
         <div class="square" style="--i:0;"></div>  
         <div class="square" style="--i:1;"></div>  
         <div class="square" style="--i:2;"></div>  
         <div class="square" style="--i:3;"></div>  
         <div class="square" style="--i:4;"></div>  
         <div class="container">  


    <form class="form" action="" method="post">
    <!-- <h1 class="login-title">Registration</h1> -->
    <div class="input__box">
        
        <input type="text" class="login-input" name="username" placeholder="User Name" readonly value="<?php echo $aaa; ?>"  />
        </div>
        <div class="input__box">
        <input type="text" class="login-input" name="email" placeholder="Course Name" readonly value="<?php echo $_GET['name']; ?>" />
        </div>
        <div class="input__box">
        <input type="text" class="login-input" name="number" placeholder="Number">
        </div>
        

        <div class="input__box">   
        <input type="radio" id="Bkash" name="pay" value="Bkash">
<label for="Bkash">Bkash</label>
 <input type="radio" id="Nagad" name="pay" value="Nagad">
 <label for="Nagad">Nagad</label>

</div>


        <div class="input__box">
        <input type="text" class="login-input" name="T_id" placeholder="Transaction ID">
        </div>
        <div class="input__box">
        <input type="submit" name="submit" value="Register" class="login-button">
    </div>
        <p class="link"><a href="main_menu_std.php">Back to Main Menu</a></p>
    </form>
<?php
    }
?>


</div>  
         </div>  
    </div>  
</section> 


</body>
</html>



    
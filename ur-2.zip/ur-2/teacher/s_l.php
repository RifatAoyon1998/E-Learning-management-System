<?php
include("auth_session.php");
$user = 'root';
$password = '';

// Database name is geeksforgeeks
$database = 'ABC';

// Server is localhost with
// port number 3306
$servername='localhost:3306';
$mysqli = new mysqli($servername , $user,
				$password, $database);

// Checking for connections
if ($mysqli->connect_error) {
	die('Connect Error (' .
	$mysqli->connect_errno . ') '.
	$mysqli->connect_error);
}
$aaa=$_GET['name'];
$sql = " SELECT * from crud_2 where phone='$aaa'";
$result = $mysqli->query($sql);


$sql_about = " SELECT * FROM `payment_std`";
$result_about = $mysqli->query($sql_about);
?>


<html>
    <body>
      
  


  <?php
  // LOOP TILL END OF DATA
  while($rows=$result->fetch_assoc())
  {
?>



<div class="box one">
<!-- <div class="date">
<h4>6/29/18</h4>
</div> -->

<!-- <p class="card-text"></p> -->
<a href="submit_marks.php?name=<?php echo $rows['id'];?>"><h1> Name:<?php echo $rows['name'];?> 


ID:<?php echo $rows['id'];?></h1> </a>

</div>


</div>


<?php
  }
?> 


    </body>
</html>
<?php
include("auth_session.php");
// Username is root
$user = 'root';
$password = '';

// Database name is geeksforgeeks
$database = 'ABC';

// Server is localhost with
// port number 3306
$servername='localhost:3306';
$mysqli = new mysqli($servername , $user,
				$password, $database);

// Checking for connections
if ($mysqli->connect_error) {
	die('Connect Error (' .
	$mysqli->connect_errno . ') '.
	$mysqli->connect_error);
}


$aaa = $_SESSION['username'];

$sql_about = "SELECT * FROM `teacher` WHERE username='$aaa'";
$result_about = $mysqli->query($sql_about);



$row_about = $result_about->fetch_assoc();

$name=$row_about['username'];
echo $name;
?>
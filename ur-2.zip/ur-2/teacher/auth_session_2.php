<?php
    session_start();
    if(!isset($_SESSION["c_name"])) {
        header("Location: otp_submit.php");
        exit();
    }
?>

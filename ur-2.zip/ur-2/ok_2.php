<?php

include("auth_session.php");
// Username is root
$user = 'root';
$password = '';

// Database name is geeksforgeeks
$database = 'ABC';

// Server is localhost with
// port number 3306
$servername='localhost:3306';
$mysqli = new mysqli($servername , $user,
				$password, $database);

// Checking for connections
if ($mysqli->connect_error) {
	die('Connect Error (' .
	$mysqli->connect_errno . ') '.
	$mysqli->connect_error);
}


$click=$_GET['name'];

$aaa = $_SESSION['username'];

$sql_about = " SELECT * FROM `crud` WHERE phone='$click'";
$result_about = $mysqli->query($sql_about);
$row_about = $result_about->fetch_assoc();










$sentence = $row_about['pre'];

$store = explode(" ",$sentence);

$musthave=$store;
// echo $sentence;


$sql = " SELECT * FROM `crud_2` WHERE name='$aaa'";
$result = $mysqli->query($sql);
// $row = $result->fetch_assoc();

$test1=array();
$i=0;

while($rows=$result->fetch_assoc())
                {
                   
                  
                    $test1[$i]=$rows['phone'];
$i++;
// echo $rows['phone'];
                }


                $containsAllNeeded = 0 == count(array_diff($musthave, $test1));
                // $abc=array_diff($musthave, $test1);
                $abc=array_diff($musthave, $test1);
                if($containsAllNeeded ==1){
                
                
                 
                ?>
                
                
                <?php
                }
                else{
                ?>
                    <html>
                    <body>
                         <?php 
                
                
                

                if($abc[0]!=null){
                    echo "Please Complete ";

                    for($i=0; $i<3;$i=$i+1){
                        echo $abc[$i]." ";
                        // echo $store[$i];
                    }
                }


                       else{
                        
                         ?>
<html>
                    <body>
                        <h1>Welcome to <?php echo $_GET['name']; ?></h1>
                      <a href="third_for_demo.php?p=<?php echo $_GET['name']; ?>">  <h1>Click here </h1></a>

                      <a href="enr_req.php?name=<?php echo $_GET['name']; ?>">
<p>Registration</p></a>
                </body>
                </html>
                <?php
                       }
                       ?>


                </body>
                </html>
                
                <?php
                }
                ?>
                
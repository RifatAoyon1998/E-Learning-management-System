<?php
//include auth_session.php file on all user panel pages
include("auth_session.php");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Dashboard - Client area</title>
    <link rel="stylesheet" href="style.css" />
</head>
<body>
    <div class="form">
       <h1> <p>Hey, <?php echo $_SESSION['username']; ?>!</p>
        <p>You are in user dashboard page.</p></h1>
        <a href='samplecrud/'>    <p>Course List</p></a>
        <a href='samplecrud_2/'> <p>Enrolled Student List</p></a>
       <a href="c_req_T.php"> <p>Add Course Request</p></a>
       <a href="c_req.php">  <p>Request for enrolling in a course</p></a>
       <a href='admin_file_upload.php'> <p>Uploaded Files </p></a>

   
       

        <p><a href="logout.php">Logout</a></p>
    </div>
</body>
</html>

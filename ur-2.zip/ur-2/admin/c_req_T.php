<?php
include("auth_session.php");
$user = 'root';
$password = '';

// Database name is geeksforgeeks
$database = 'ABC';

// Server is localhost with
// port number 3306
$servername='localhost:3306';
$mysqli = new mysqli($servername , $user,
				$password, $database);

// Checking for connections
if ($mysqli->connect_error) {
	die('Connect Error (' .
	$mysqli->connect_errno . ') '.
	$mysqli->connect_error);
}

$sql = " SELECT * from payment_teacher";
$result = $mysqli->query($sql);


$sql_about = " SELECT * FROM `payment_teacher`";
$result_about = $mysqli->query($sql_about);
?>


<html>
    <body>
      
  


  <?php
  // LOOP TILL END OF DATA
  while($rows=$result->fetch_assoc())
  {
?>



<div class="box one">
<!-- <div class="date">
<h4>6/29/18</h4>
</div> -->

<!-- <p class="card-text"></p> -->
<a href="req_course_info.php?name=<?php echo $rows['T_id'];?>"><h1> Name:<?php echo $rows['username'];?> 


ID:<?php echo $rows['T_id'];?></h1> </a>

</div>


</div>


<?php
  }
?> 


    </body>
</html>
<?php
require('db.php');

// Username is root
$user = 'root';
$password = '';

// Database name is geeksforgeeks
$database = 'ABC';

// Server is localhost with
// port number 3306
$servername='localhost:3306';
$mysqli = new mysqli($servername , $user,
				$password, $database);

// Checking for connections
if ($mysqli->connect_error) {
	die('Connect Error (' .
	$mysqli->connect_errno . ') '.
	$mysqli->connect_error);
}

// SQL query to select data from database



// $row_about = $result_about->fetch_assoc();

// $aaa=$row_about['phone'];


// echo $aaa;


$sql_again = "SELECT * FROM `crud`";
$result_again = $mysqli->query($sql_again);

// $row_again = $result_again->fetch_assoc();

// $abc=$row_again['name'];
// echo $abc;








     $aa= '/Applications/XAMPP/xamppfiles/htdocs/ur/';
    //  echo $aa;
    //  echo '----------';
 
    //  mkdir($aa. $row_about['phone']);
    // mkdir($aa);

    
    

while($row_again = $result_again->fetch_assoc()){

    mkdir($aa.$row_again['name'].$row_again['phone']);

}

$ab= '/Applications/XAMPP/xamppfiles/htdocs/ur/';

$sql = "SELECT * FROM `crud_2`";
$result = $mysqli->query($sql);


while($row = $result->fetch_assoc()){

    mkdir($ab.$row['name'].$row['phone']);

}




$mysqli->close();
?>


<html>
    <body>
     <a href="dashboard.php">   <h1>Registration Complete</h1></a>
</body>
    </html>





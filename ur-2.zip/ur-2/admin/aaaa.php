<html>
    <body>
    <a href="../hi_3.php">    <p>OK</p></a>
    </body>
</html>
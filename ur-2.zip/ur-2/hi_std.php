<?php
require('db.php');

// Username is root
$user = 'root';
$password = '';

// Database name is geeksforgeeks
$database = 'ABC';

// Server is localhost with
// port number 3306
$servername='localhost:3306';
$mysqli = new mysqli($servername , $user,
				$password, $database);

// Checking for connections
if ($mysqli->connect_error) {
	die('Connect Error (' .
	$mysqli->connect_errno . ') '.
	$mysqli->connect_error);
}




$sql_about = "SELECT * FROM `crud_2`";
$result_about = $mysqli->query($sql_about);





$sql_again = "SELECT * FROM `crud` WHERE phone='$aaa'";
$result_again = $mysqli->query($sql_again);




$sql_all = "SELECT * FROM `crud`";
$result_all = $mysqli->query($sql_all);


 mkdir('abcdCSE431');





$mysqli->close();
?>


<html>
    <body>
     <a href="">   <h1>Registration Complete</h1></a>
</body>
    </html>





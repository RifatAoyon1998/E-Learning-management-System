-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 04, 2022 at 12:54 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `login_sample_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `users_2_Lec`
--

CREATE TABLE `users_2_Lec` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users_2_Lec`
--

INSERT INTO `users_2_Lec` (`id`, `username`, `password`, `created_at`) VALUES
(1, 'www.w3school.com', '$2y$10$9MmkpDTwhdGX3hk5HgSCNOd0vs9ugWhkl9As9qTIC8rUPt/8f6G.q', '2021-12-03 05:54:26'),
(2, 'www.abcd.com', '$2y$10$nSPeO.W0W9ddSTlYGekjCOstSlW3dGhnfia40Qbx1Xq8Q25zqTML.', '2021-12-31 11:47:23'),
(3, 'www.cse111.com', '$2y$10$fY/lQQJq3ZvAHqn6Ov7e6ejsAy5n4KcixySchmdU7Rrfq.hpRyw1W', '2021-12-31 11:56:44'),
(5, 'www.lec.com', '$2y$10$/6aDzwJCb8A6ud4GmUDAe.mt1fW0fS9tPVschN5U/G5WAMddUrs0C', '2022-01-03 23:44:40');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users_2_Lec`
--
ALTER TABLE `users_2_Lec`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users_2_Lec`
--
ALTER TABLE `users_2_Lec`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 04, 2022 at 12:45 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `login_sample_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `Exam_Con`
--

CREATE TABLE `Exam_Con` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Exam_Con`
--

INSERT INTO `Exam_Con` (`id`, `username`, `password`, `created_at`) VALUES
(1, 'Exam_controller', '$2y$10$vADudBNPZqJhl5/UdJ4Z9eY6Yo1w6PA/WPdWolU79kUCEbhrO3H6a', '2021-12-03 23:46:21'),
(2, 'check_it', '$2y$10$GGQ5s1x.t2cDYD/QHXFRNu7jxq0fNmSHzJ9PqbHZMzczRC88Aesl.', '2021-12-04 03:08:47'),
(3, 'ok', '$2y$10$N4pCs/CAWGGDs2qjGlwF2.vZOhItf5wDFKPqbSTyHk.vUd/ugPivK', '2021-12-04 03:09:24'),
(4, 'another', '$2y$10$Kff.i7jrN87bruW9HXKY..SIeEzNLzoE8UYpWHrD63kIptaTjmjji', '2021-12-04 03:29:53'),
(12516560, 'ok_try', '123456', '2021-12-04 03:55:56'),
(12516561, 'jjnjnjnjnjnjnjnj', '$2y$10$jWXxzcHoIv.eaykzfudcROi0qy4TSWZfUHFAsogNXht.VEOXKFYMG', '2021-12-04 05:51:27'),
(12516562, 'hi', '$2y$10$cLxosLJGo4stNZbP4hkxuOnVSejJLmruK.AtETcNBSALxDdKlK6yu', '2021-12-04 06:27:13'),
(12516563, 'how', '$2y$10$2lVCio1fke.j3nx51qOAyeDLAFzob3T8TutV4sOFe.UNIKbhB4WDe', '2021-12-04 06:28:10'),
(12516564, 'hi_hello', '$2y$10$5xCZMYRVjhr5bBzC2MNayOhkay1Hr2nLwov5Dz0yKKIfa4Zfg0Lve', '2021-12-04 07:22:02'),
(12516565, 'what', '$2y$10$BAI/ECFTuHAWGTzoyJ8XFu9RAk3QevhEMo/fkXqFSEGJVlpjEf7GW', '2021-12-31 13:33:16'),
(12516566, 'exm', '$2y$10$GraVgt44qEDMeGjv5f6w.uyT4oz3NEPi.OGYItK5kVWVRHyzNr0C6', '2022-01-02 19:04:59'),
(12516567, 'lll', '$2y$10$moSfyQ2KGhRXaqrmh8OGQegb67bvGp15oYbIx65GNzpHFp0mz5pIO', '2022-01-03 14:38:08'),
(12516568, 'abcde', '$2y$10$pMoR01y6MA7.fFWwsC387OV.vgFjODOaS5tBLIeA7D/V87.iMi6ee', '2022-01-03 17:23:53'),
(12516569, 'Mr_ABCD', '$2y$10$WDK3N/MUu4.xZ7lxBbipFeL4lYlc3VnKT1E0GWu55s8sXK7tOAkaC', '2022-01-03 23:27:30');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Exam_Con`
--
ALTER TABLE `Exam_Con`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Exam_Con`
--
ALTER TABLE `Exam_Con`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12516570;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

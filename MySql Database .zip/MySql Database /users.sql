-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 04, 2022 at 12:54 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `login_sample_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_id`, `user_name`, `password`, `date`) VALUES
(1, 6469714075967953204, 'aoyon', '1234', '2021-12-01 17:44:04'),
(2, 37287913764, 'Hello', '1234', '2021-12-01 18:05:58'),
(3, 3075701844, 'Ar', '123456', '2021-12-01 18:13:45'),
(4, 29598, 'random', '1234', '2021-12-01 18:15:08'),
(5, 72498810222552154, 'Hi', '1234', '2021-12-01 18:16:22'),
(6, 527866301319, 'qwer', '1234', '2021-12-01 18:20:34'),
(7, 3495680599530, 'XYZ', '1234', '2021-12-01 18:25:59'),
(8, 9237813549, 'XYZ_M', '1234', '2021-12-01 18:27:11'),
(9, 76656, 'nice', '1234', '2021-12-01 21:47:25'),
(10, 2227, 'hmm', '1234', '2021-12-01 21:48:36'),
(11, 22701, 'hello_1', '1234', '2021-12-02 12:33:22'),
(12, 889962329025631, 'qur', '1234', '2021-12-02 13:04:04'),
(13, 6145, 'zoom', '1234', '2021-12-02 13:29:49'),
(14, 639245390, 'another_one', '1234', '2021-12-02 17:44:42'),
(15, 7169896684815200, 'another_student', '1234', '2021-12-03 13:54:31'),
(16, 4031381393068705045, 'let see', '1234', '2021-12-03 13:56:04'),
(17, 4747966675285314, 'how_are_you', '123456', '2021-12-04 00:35:11'),
(18, 3882087373642, 'ok_see', '123456', '2021-12-31 06:12:15'),
(19, 94666039826, 'ok_an', '123456', '2021-12-31 06:14:11'),
(20, 572969737840, 'abcd', '123456', '2022-01-03 17:31:09');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `user_name` (`user_name`),
  ADD KEY `date` (`date`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

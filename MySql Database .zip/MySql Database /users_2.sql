-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 04, 2022 at 12:54 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `login_sample_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `users_2`
--

CREATE TABLE `users_2` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users_2`
--

INSERT INTO `users_2` (`id`, `username`, `password`, `created_at`) VALUES
(1, '', '$2y$10$QpcnzsJjUPr0B/QFEk/xr.OttSzdoJE742hljU4jrouTfN/8hLU7C', '2021-12-03 03:28:43'),
(3, 'asasadsfdg', '$2y$10$JT.0xTMepm0yFwggTQBs8Onu2fhIS70ricVy5DmINQ0HKyREj2suK', '2021-12-03 03:29:35'),
(4, 'asanjsanjna', '$2y$10$lbNaeBz5bfSwpHSgtFeYCejns/w1bvFriJJ9B7dAQolAdmkQj6Qda', '2021-12-03 03:29:46'),
(5, 'Professor_ABC', '$2y$10$IUoA8spviZY7eetlXOH4h.O2lmFTQxDsGRZ/Wgi6qqb1k.LlCf9DS', '2021-12-03 03:35:56'),
(6, 'hello', '$2y$10$6AS0T1iA1HspvFOxDXQ62.n21kTAX0FeOusXOA0aD9M4rNMjH1L8a', '2021-12-03 03:46:17'),
(7, 'www.google.com', '$2y$10$9i/vUcrfPGkAa3acMN0fmu0QMfXyOu8.vjMueI/GdwkslobiQ.BeS', '2021-12-03 04:44:29'),
(8, 'Prof_Mac', '$2y$10$g97OS0ErMhXXd4wgNQXrRuGSgjZiuDy7jJ6Hrk9IQFUeL4hCpLp4.', '2021-12-03 20:02:14'),
(9, 'hello_3', '$2y$10$h3ZIf.QyNz89i2xWDZnSSuZD6211ke6lDfIPv0z.Y1HGCR60HogAu', '2021-12-03 23:59:40'),
(10, 'Mr_AAA', '$2y$10$G6Wik.JEE1pZFr6mGmCPwOI6YIccwfnAfuCCqTu9/Wx0M3A42ALNe', '2021-12-04 03:13:42'),
(11, 'sasadad', '$2y$10$fd.EQzIb9Sc1FcClZNHsV.xvRdi1S6BUKEt3Lftw.7IGUAeoozvW6', '2021-12-04 04:22:51'),
(12, 'hhhhhhh', '$2y$10$XXwRfY2g76wCM3Tl0V/sxemB5pHZlYyjbYuHoD0YFyPFZulzOl3Fy', '2021-12-04 05:42:29'),
(13, 'mskamksmaksm', '$2y$10$DHwf3gFwJWJ1MYxun2JboO3fJpy5r7h1Et5ClJXIWlUUAeG4BpYXq', '2021-12-04 05:50:33'),
(14, 'abcdefghi', '$2y$10$hp14hMCdAzngHWEfcfJBR.FkeNk9B4Pg/wZwRbkCTypF1UBX7biJC', '2021-12-04 06:25:30'),
(15, 'right', '$2y$10$8hihkSlg74nu350Op1ZCmu0k2vCZr.00qjGeS/8OTGP/fePtMRY5W', '2021-12-04 06:31:02'),
(16, 'let', '$2y$10$7iUcDRBY8ToMP5RGV8pJn.3HFBfaeinc1s4NnPkjGOTNl0QudLHEe', '2021-12-04 07:17:49'),
(17, 'how_are_you', '$2y$10$dWztigpNAzMbd.cjfJdPzePd0I9G32vDsBU6yDmN1ewzNmFx13sBa', '2021-12-15 19:46:35'),
(18, 'ok_try_an', '$2y$10$QgfkGRi5viGpURTRMrV2zO1rzQYoUBJCNyoNE4JBvrV006TY21M8G', '2021-12-31 11:26:45'),
(19, 'teach', '$2y$10$P6SQ.zIaTDEW5wN8AmoIWeeeAl50as2p/b4e5BGnbV3.IP3nDzkXy', '2022-01-02 19:02:29'),
(20, 'Professor', '$2y$10$VjQMWRdMwAOyT6LBRtZ8pu/aly/X2N/pBKIOVF1fF3XQeDWFlrVDG', '2022-01-03 23:33:37');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users_2`
--
ALTER TABLE `users_2`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users_2`
--
ALTER TABLE `users_2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
